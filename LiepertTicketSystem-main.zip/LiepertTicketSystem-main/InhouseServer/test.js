// test-post.js

// ---- Testdaten (5 Einträge) ----
const testEintraege = [
  {
    lfdNr: 1001,
    DATUM: "2025-01-15",
    Mitarbeiter: "Müller Max",
    PRJ: "PRJ-2025-001",
    TicketNr: "TCK-12345",
    StundenBuchung: 2.5,
    Zeitvon: "08:00",
    Zeitbis: "10:30",
    ZEIT: 2.5,
    ZEIT_OB: 0,
    Art: "Support",
    Leistung: "Fehleranalyse",
    interneBemerkung: "Kunde telefonisch betreut",
    VORORT: 0,
    KM: 0,
    FAHRZEIT: 0,
    FAHRZEUG: "",
    Zeitstempel: "2025-01-15 10:35:00",
    neuerEintrag: true
  },
  {
    lfdNr: 1002,
    DATUM: "2025-01-16",
    Mitarbeiter: "Schmidt Anna",
    PRJ: "PRJ-2025-002",
    TicketNr: "TCK-98765",
    StundenBuchung: 1.0,
    Zeitvon: "11:00",
    Zeitbis: "12:00",
    ZEIT: 1.0,
    ZEIT_OB: 0,
    Art: "Beratung",
    Leistung: "Planungsmeeting",
    interneBemerkung: "Projektbesprechung",
    VORORT: 0,
    KM: 0,
    FAHRZEIT: 0,
    FAHRZEUG: "",
    Zeitstempel: "2025-01-16 12:05:00",
    neuerEintrag: true
  },
  {
    lfdNr: 1003,
    DATUM: "2025-01-17",
    Mitarbeiter: "Klein Lukas",
    PRJ: "PRJ-2025-010",
    TicketNr: "TCK-54321",
    StundenBuchung: 4.0,
    Zeitvon: "07:30",
    Zeitbis: "11:30",
    ZEIT: 4.0,
    ZEIT_OB: 0.5,
    Art: "Wartung",
    Leistung: "Systemupdate",
    interneBemerkung: "Updates installiert",
    VORORT: 1,
    KM: 42,
    FAHRZEIT: 0.75,
    FAHRZEUG: "VW-Bus",
    Zeitstempel: "2025-01-17 11:40:00",
    neuerEintrag: true
  },
  {
    lfdNr: 1004,
    DATUM: "2025-01-18",
    Mitarbeiter: "Becker Julia",
    PRJ: "PRJ-2025-050",
    TicketNr: "",
    StundenBuchung: 3.0,
    Zeitvon: "09:00",
    Zeitbis: "12:00",
    ZEIT: 3.0,
    ZEIT_OB: 0,
    Art: "Intern",
    Leistung: "Dokumentation",
    interneBemerkung: "Prozessbeschreibung aktualisiert",
    VORORT: 0,
    KM: 0,
    FAHRZEIT: 0,
    FAHRZEUG: "",
    Zeitstempel: "2025-01-18 12:02:00",
    neuerEintrag: true
  },
  {
    lfdNr: 1005,
    DATUM: "2025-01-19",
    Mitarbeiter: "Fischer Tom",
    PRJ: "PRJ-2025-200",
    TicketNr: "TCK-11223",
    StundenBuchung: 6.5,
    Zeitvon: "06:00",
    Zeitbis: "12:30",
    ZEIT: 6.5,
    ZEIT_OB: 1.0,
    Art: "Installation",
    Leistung: "Servereinrichtung",
    interneBemerkung: "Neuen Server vor Ort installiert",
    VORORT: 1,
    KM: 90,
    FAHRZEIT: 1.5,
    FAHRZEUG: "Transporter",
    Zeitstempel: "2025-01-19 12:40:00",
    neuerEintrag: true
  }
];

// ---- URL deines Endpoints ----
const URL = "http://localhost:3000/api/stunden"; // ← anpassen!

// ---- POST Funktion ----
async function sendEintraege() {
  try {
    const response = await fetch(URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({testEintraege, session_token: "dfdb88a0dbec1bd0ec5f3a0871584402fc272af16c7509ebb6a2988d608337b5"})
    });

    const result = await response.json();
    console.log("Antwort vom Server:");
    console.log(result);

  } catch (error) {
    console.error("Fehler beim Senden:", error);
  }
}

async function testAuthentication(){
    const password = "aLxxdUp^ro]+WrJ]k8gCv_DZC?v8xyGjm}nDc]@2i5^wR10R_Q!RqLT";
    const email = "connector@liepert.de";
    try{
        const response = await fetch('http://localhost:3030/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
            credentials: 'include'
        });
        if (!response.ok) {
          console.log(response);
            throw new Error(`HTTP-Fehler! Status: ${response}`);

        }
        const data = await response.json();
        console.log("Authentifizierung erfolgreich:", data);
    } catch (error) {
        console.error("Fehler bei der Authentifizierung:", error);
    }
}

// ---- Script starten ----
sendEintraege();
