async function ladeKunden(){
    const response = await fetch('/api/kunden');
    if(!response.ok){
        console.error('Fehler beim Laden der Kunden:', response.details);
        showErrorBanner('Fehler beim Laden der Kunden');
        return;
    }
    const kunden = await response.json();
    const tableBody = document.getElementById('systemverwaltung_tabelle_body');
    tableBody.innerHTML = '';
    kunden.forEach(async (kunde) => {
        const heute = new Date().toISOString().split('T')[0];
        const projektResponse = await fetch(`/api/projekte?kunde=${kunde.kunden_id}&datum=${heute}`);
        const projekte = await projektResponse.json();
        console.log(projekte);
        const row = document.createElement('tr');
        const kundenname = document.createElement('td');
        kundenname.textContent = kunde.kunde_name;
        const projektname = document.createElement('td');
        let projektText;
        if(projektResponse.length !== 0){
            projektText = "Ja"
            projekte.forEach(projekt => {
                projektText += ", " + projekt.PRJ;
            })
        } else {
            projektText = "Nein"
        }
        projektname.textContent = projektText;

        const kundenadministratoren = document.createElement('td');
        row.appendChild(kundenname);
        row.appendChild(projektname);
        row.appendChild(kundenadministratoren);
        const kundenadmins = kunde.kundenadministratoren;
        kundenadmins.forEach(admin => {
            console.log(admin.nachname);
            const div = document.createElement('div');
            div.className = 'adminEintragContainer';
            const left = document.createElement('div');
            const right = document.createElement('div');
            left.textContent = admin.vorname + " " + admin.nachname;
            /*right.innerHTML = `
                <svg class="deleteAdmin" xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="var(--failed-color)"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z"/>
                </svg>
            `;
            right.addEventListener('click', () => {
                entferneFirmenadmin(admin);
            });*/
            div.classList.add('adminEintrag');
            div.appendChild(left);
            div.appendChild(right);
            kundenadministratoren.appendChild(div);
        });
        tableBody.appendChild(row);
    });
}

function entferneFirmenadmin(admin){
    if(confirm('Möchten Sie den Firmenadministrator "' + admin.admin_name + '" wirklich entfernen? Hierbei wird nicht der Benutzer gelöscht sondern nur die Zuordnung als Firmenadministrator aufgehoben.')){
        // Hier würde der Code zum Entfernen des Admins eingefügt werden
        console.log('Bestätigt: Entferne Firmenadmin mit ID:', admin.adminId);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    ladeKunden();
});