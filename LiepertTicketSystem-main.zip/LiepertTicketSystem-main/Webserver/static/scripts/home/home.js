async function onLoad(){
    const response = await fetch("/me", {
        method: "GET",
        credentials: "include"
    });
    const benutzer = await response.json();
    if(!response.ok) {
        console.error("Failed to fetch user data" + response.status + " " + benutzer.details);
        window.location.href = "/login";
        return;
    }


    ladeTickets(benutzer);
    ladeBenutzer(benutzer);
    erstelleTicketUebersicht(benutzer);
}

document.addEventListener("DOMContentLoaded", onLoad);