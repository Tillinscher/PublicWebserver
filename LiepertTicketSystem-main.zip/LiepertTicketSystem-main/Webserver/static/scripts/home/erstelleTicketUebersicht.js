async function erstelleTicketUebersicht(benutzer){
    const ticketDiagramm = document.getElementById("ticketChart");
    const styles = getComputedStyle(document.documentElement);
    const gelesene_farbe = styles.getPropertyValue("--gelesene-color").trim();
    const ungelesene_farbe = styles.getPropertyValue("--ungelesene-color").trim();
    const bearbeitung_farbe = styles.getPropertyValue("--bearbeitung-color").trim();

    try{
        const url = benutzer.kunde === 1 ? `/api/ticketanzahl?bearbeiter=${benutzer.benutzer_id}` : `/api/ticketanzahl?ersteller=${benutzer.benutzer_id}`;

        const response = await fetch(url, {
            method: "GET",
            credentials: "include"
        });
        if(!response.ok) {
            throw new Error("Ticket Übersicht konnte nicht geladen werden: " + response.status);
        }
        const ticketArray = await response.json();
        const ticketDaten = await ticketArray[0];

        document.getElementById("ungelesen_anzahl").innerText = ticketDaten.ungelesen;
        document.getElementById("gelesen_anzahl").innerText = ticketDaten.gelesen;
        document.getElementById("bearbeitung_anzahl").innerText = ticketDaten.bearbeitung;

        const ctx = ticketDiagramm.getContext('2d');
        new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Ungelesen', 'Gelesen', 'In Bearbeitung'],
                datasets: [{
                    data: [ticketDaten.ungelesen, ticketDaten.gelesen, ticketDaten.bearbeitung],
                    backgroundColor: [ ungelesene_farbe, gelesene_farbe, bearbeitung_farbe ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                }
            }
        });
    } catch(error){
        console.error("Fehler beim Erstellen der Ticket Übersicht: " + error);
        document.getElementById("kreisdiagramm").innerHTML = `<p>Fehler beim Laden der Ticket Übersicht</p>`;
    }
}