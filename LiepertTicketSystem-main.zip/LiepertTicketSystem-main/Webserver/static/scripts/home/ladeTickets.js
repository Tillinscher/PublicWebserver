async function ladeTickets(benutzer){
    const ticketTabelle = document.getElementById("ticket_tabelle");
    const thead = document.createElement("thead");
    thead.innerHTML = `
        <tr>
            <th>Ticketnr.</th>
            <th>Beschreibung</th>
            ${benutzer.rolle === "techniker" ? "<th>Kunde</th>" : ""}
            <th>Letzte Änderung</th>
        </tr>
    `
    ticketTabelle.appendChild(thead);
    const tbody = document.createElement("tbody");

    const fetchLink = benutzer.kunde === 1 ? `/api/tickets?bearbeiter=${benutzer.benutzer_id}` : `/api/tickets?ersteller=${benutzer.benutzer_id}`;

    try{
        const ticketResponse = await fetch(fetchLink, {
            method: "GET",
            credentials: "include"
        });

        if(!ticketResponse.ok) {
            throw new Error("Tickets konnten nicht geladen werden: " + ticketResponse.status);
        }

        const tickets = await ticketResponse.json();

        if(tickets.length === 0) {
            const tr = document.createElement("tr");
            tr.innerHTML = `<td colspan="${benutzer.rolle === "techniker" ? 4 : 3}">Keine Tickets vorhanden</td>`;
            tbody.appendChild(tr);
            return;
        }

        tickets.forEach(ticket => {
            const tr = document.createElement("tr");
            const {year, month, day} = splitSQLDateTime(
                ticket.letzte_bearbeitung === null ? ticket.geaendert : ticket.letzte_bearbeitung
            );
            tr.innerHTML = `
                <td>${ticket.erp_ticketnr === null ? "N/A" : ticket.erp_ticketnr}</td>
                <td>${ticket.beschreibung}</td>
                ${benutzer.rolle === "techniker" ? `<td>${ticket.kunde_name}</td>` : ""}
                <td>${day + "." + month + "." + year}</td>
            `;
            tr.addEventListener("click", () => {
                window.location.href = `/ticket?ticketId=${ticket.ticket_id}`;
            });
            tbody.appendChild(tr);
        });
    } catch(error){
        console.error("Fehler beim Tickets Laden: " + error);
        const tr = document.createElement("tr");
        tr.innerHTML = `<td colspan="${benutzer.rolle === "techniker" ? 4 : 3}">Fehler beim Laden der Tickets</td>`;
        tbody.appendChild(tr);
    }

    
    ticketTabelle.appendChild(tbody);
}

function splitSQLDateTime(sqlDateTime) {
    if (!sqlDateTime) {
      return { year: null, month: null, day: null, hours: null, minutes: null, seconds: null };
    }
  
    const date = new Date(sqlDateTime);
  
    return {
      year: date.getUTCFullYear(),
      month: String(date.getUTCMonth() + 1).padStart(2, "0"),
      day: String(date.getUTCDate()).padStart(2, "0"),
      hours: String(date.getUTCHours()).padStart(2, "0"),
      minutes: String(date.getUTCMinutes()).padStart(2, "0"),
      seconds: String(date.getUTCSeconds()).padStart(2, "0"),
    };
}