async function ladeBenutzer(benutzer){
    const benutzercontainer = document.getElementById('benutzer_container');
    if(benutzer.rolle !== 'Firmenadministrator' && benutzer.rolle !== 'Systemadministrator'){
        benutzercontainer.style.display = 'none';
        return;
    }
    benutzercontainer.style.display = 'flex';

    const benutzerTabelle = document.getElementById('benutzer_tabelle');
    benutzerTabelle.innerHTML = '';
    const thead = document.createElement('thead');
    thead.innerHTML = `
        <tr>
            <th>Name</th>
            <th>Letzte Anmeldung</th>
        </tr>
    `;
    benutzerTabelle.appendChild(thead);

    const tbody = document.createElement('tbody');

    try{
        const benutzerResponse = await fetch(`/api/benutzer?kunde=${benutzer.kunde}`, {
            method: "GET",
            credentials: "include"
        });
        if(!benutzerResponse.ok) {
            throw new Error("Benutzer konnten nicht geladen werden: " + benutzerResponse.status);
        }
        const benutzerListe = await benutzerResponse.json();

        benutzerListe.sort((a, b) => {
            const datumA = a.letzte_aktion ? new Date(a.letzte_aktion) : 0;
            const datumB = b.letzte_aktion ? new Date(b.letzte_aktion) : 0;
            return datumB - datumA;
        });

        if(benutzerListe.length === 0) {
            const tr = document.createElement("tr");
            tr.innerHTML = `<td colspan="2">Keine Benutzer vorhanden</td>`;
            tbody.appendChild(tr);
        } else {
            benutzerListe.forEach(benutzer => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${benutzer.nachname}, ${benutzer.vorname}</td>
                    <td>${benutzer.letzte_aktion ? new Date(benutzer.letzte_aktion).toLocaleDateString("de-DE") : "Nie"}</td>
                `;
                tbody.appendChild(tr);
            });
        }

    } catch(error){
        console.error("Fehler beim Benutzer Laden: " + error);
        const tr = document.createElement("tr");
        tr.innerHTML = `<td colspan="2">Fehler beim Laden der Benutzer</td>`;
        tbody.appendChild(tr);
    }

    benutzerTabelle.appendChild(tbody);
}