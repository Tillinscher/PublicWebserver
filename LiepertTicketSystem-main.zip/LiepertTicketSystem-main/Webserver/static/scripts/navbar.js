const body = document.body;

async function loadNavbar() {
        const response = await fetch("/me", {
            method: "GET",
            credentials: "include"
        })
        .catch(err => {
            console.log("Fehler beim Laden der Navbar");
        })

        if(!response.ok) {
            console.error("Failed to fetch user data");
            return;
        }

        const userData = await response.json();

        
        const navbar = document.createElement("nav");

        navbar.innerHTML = `
            <div class="nav-left">
                <div id="homeNav" class="navbarButton">Home</div>
                <div id="ticketsNav" class="navbarButton">Tickets</div>
                ${userData.rolle === "Firmenadministrator" || userData.rolle === "Systemadministrator"
                ? '<div id="firmenverwaltungNav" class="navbarButton">Firmenverwaltung</div>'
                : ""}
                ${userData.rolle === "Systemadministrator"
                ? '<div id="systemverwaltungNav" class="navbarButton">Systemverwaltung</div>'
                : ""}
            </div>
            <div class="nav-right">
                <div id="neuesTicketNav" class="navbarButton">Ticket erstellen</div>
                <div id="benutzerDropdown" class="navbarDropdown">
                    <div id="benutzernameNav" class="navbarButton">${userData.nachname}</div>
                    <div id="logoutButton" class="logoutButton">Logout&nbsp;&nbsp;&nbsp;<!--<img class="logout-img" src="../img/logout_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg">--></div>
                </div>
            </div>
        `;

        body.appendChild(navbar);


        const benutzerPopup = document.createElement('div');
        benutzerPopup.id = "benutzerPopup";
        benutzerPopup.innerHTML = `
            <div class="popup_content">
                <h2>Benutzerübersicht</h2>
                <form id="benutzerForm" class="popupForm">
                    <label>Vorname: ${userData.vorname}</label>
                    <label>Nachname: ${userData.nachname}</label>
                    <label>E-Mail Adresse: ${userData.email}</label>
                    <label>Rolle: ${userData.rolle}</label><br>
                    <input type="password" placeholder="Neues Passwort..." id="neuesBenutzerPasswort"><br>
                    <input type="password" placeholder="Passwort bestätigen..." id="neuesBenutzerPasswortCheck">
                    <div class="btn_popup_container">
                        <button id="benutzerSpeichern">Speichern</button>
                        <button id="benutzerAbbrechen">Schließen</button>
                    </div>
                </form>
            </div>
        `;
        body.appendChild(benutzerPopup);

        document.getElementById("benutzerAbbrechen").addEventListener("click", () => {
            benutzerPopup.style.display = "none";
        });

        //const { benutzer_id, vorname, nachname, email, rolle, passwort, aktiv } = req.query;
        document.getElementById("benutzerSpeichern").addEventListener("click", async (event) => {
            event.preventDefault();
            const passwort = document.getElementById("neuesBenutzerPasswort").value;
            const passwortCheck = document.getElementById("neuesBenutzerPasswortCheck").value;
            if(passwort !== passwortCheck) return showErrorbanner("Passwörter stimmen nicht überein");
            const response = await fetch(`/api/benutzer?benutzer_id=${userData.benutzer_id}&vorname=${userData.vorname}&nachname=${userData.nachname}&email=${userData.email}&rolle=${userData.rolle}&passwort=${passwort}`, {
                method: "PUT",
                credentials: "include"
            });
            if(!response.ok) return showErrorbanner("Passwort konnte nicht gespeichert werden");
            benutzerPopup.style.display = "none";
            showSuccessBanner("Passwort erfolgreich geändert");
        })

        document.addEventListener('click', (event) => {
            if (event.target === benutzerPopup) {
                benutzerPopup.style.display = "none";
            }
        });

    document.getElementById("homeNav").addEventListener("click", () => {
        window.location.href = "/";
    });
    
    document.getElementById("ticketsNav").addEventListener("click", () => {
        window.location.href = "/tickets";
    });

    const firmenbtn = document.getElementById("firmenverwaltungNav");
    if(firmenbtn){
        firmenbtn.addEventListener("click", () => {
            window.location.href = "/firmenverwaltung";
        });
    }
    
    const systembtn = document.getElementById("systemverwaltungNav");
    if(systembtn){
        systembtn.addEventListener("click", () => {
            window.location.href = "/systemverwaltung";
        });
    }
    
    document.getElementById("neuesTicketNav").addEventListener("click", () => {
        openNewTicketModal();
    });

    document.getElementById("benutzernameNav").addEventListener("click", () => {
        openBenutzerModal();
    })
    
    document.getElementById("logoutButton").addEventListener("click", async () => {
        const response = await fetch("/logout", {
            method: "POST",
            credentials: "include"
        });
        if(response.ok){
            window.location.href = "/login";
        }else{
            console.error("Fehler beim Logout");
            showErrorbanner("Fehler beim Logout");
        }
    });
    const kundenResponse = await fetch("/api/kunden", {
        method: "GET",
        credentials: "include"
    });
    if(!kundenResponse.ok){
        console.error("Fehler beim Laden der Kundenliste");
    }
    const kundenListe = await kundenResponse.json();

    const popup = document.createElement("div");
    popup.id = "newTicketPopup";
    popup.innerHTML = `
        <div class="popup_content">
            <h2>Neues Ticket erstellen</h2>
            <form id="newTicketForm" class="popupForm">
                ${userData.kunde === 1 
                ? "<label for='neuesTicketKunde'>Kunde:</label><select id='neuesTicketKunde'></select>"
                : ''}
                <label for="description">Beschreibung:</label><br>
                <textarea id="description" name="description" required></textarea><br><br>
                <!--<label for="anhang">Anhang (optional):</label><br>
                <input type="file" name="anhang" id="anhang">-->
                <div class="btn_popup_container">
                    <button type="button" id="cancelNewTicket">Abbrechen</button>
                    <button id="erstelleNeuesTicket">Erstellen</button>
                </div>
            </form>
        </div>
    `;
    setTimeout(() => {
        const select = popup.querySelector("#neuesTicketKunde");
    }, 0);
    kundenListe.forEach(kunde => {
        const option = document.createElement("option");
        option.value = kunde.kunde_id;
        option.textContent = kunde.kunde_name;
        const select = popup.querySelector("#neuesTicketKunde");
        if(select) {
            select.appendChild(option);
        }
    });
    body.appendChild(popup);

    document.getElementById('cancelNewTicket').addEventListener('click', () => {
        popup.style.display = "none";
    });
    document.getElementById('erstelleNeuesTicket').addEventListener('click', async (event) => {
        event.preventDefault();
        erstelleTicket(userData.benutzer_id, userData.kunde);
    });
    document.addEventListener('click', (event) => {
        if (event.target === popup) {
            popup.style.display = "none";
        }
    });


    
}



function openBenutzerModal(){
    const popup = document.getElementById("benutzerPopup");
    popup.style.display = "flex";
}

function openNewTicketModal(){
    const popup = document.getElementById("newTicketPopup");
    popup.style.display = "flex";
}



function showSuccessBanner(message) {
    const banner = document.createElement("div");
    banner.textContent = message;
    banner.style.position = "fixed";
    banner.style.top = "10px";
    banner.style.left = "50%";
    banner.style.transform = "translateX(-50%)";
    banner.style.backgroundColor = "var(--success-color)";
    banner.style.color = "var(secondary-text)";
    banner.style.padding = "10px 20px";
    banner.style.borderRadius = "5px";
    banner.style.boxShadow = "0px 4px 6px var(--shadow-heavy)";
    banner.style.zIndex = "1000";

    document.body.appendChild(banner);

    setTimeout(() => {
        banner.remove();
    }, 3000);
}

function showErrorbanner(message){
    const banner = document.createElement("div");
    banner.textContent = message;
    banner.style.position = "fixed";
    banner.style.top = "10px";
    banner.style.left = "50%";
    banner.style.transform = "translateX(-50%)";
    banner.style.backgroundColor = "var(--failed-color)";
    banner.style.color = "var(secondary-text)";
    banner.style.padding = "10px 20px";
    banner.style.borderRadius = "5px";
    banner.style.boxShadow = "0px 4px 6px var(--shadow-heavy)";
    banner.style.zIndex = "1000";

    document.body.appendChild(banner);

    setTimeout(() => {
        banner.remove();
    }, 3000);
}

async function erstelleTicket(ersteller_id, ersteller_kunde)
{
    let kunde_id;
    if(ersteller_kunde !== 1){
        const kundeSelect = document.getElementById("neuesTicketKunde");
        kunde_id = kundeSelect ? kundeSelect.value : null;
    } else {
        kunde_id = ersteller_kunde;
    }
    const beschreibung = document.getElementById("description").value;
    //const anhang = document.getElementById("anhang").files[0];
    //const formData = new FormData();
    //if(anhang) formData.append("anhang", anhang);
    const query = `/api/tickets?ersteller=${encodeURIComponent(ersteller_id)}&beschreibung=${encodeURIComponent(beschreibung)}&kunde=${encodeURIComponent(kunde_id)}&status=Ungelesen`;
    const response = await fetch(query, {
        method: "POST",
        credentials: "include",
        body: {
            ersteller: ersteller_id,
            beschreibung: beschreibung,
            //formData: formData
        }
    })
    .catch (error => {
        console.error("Fehler beim Erstellen des Tickets:", error);
        showErrorbanner("Fehler beim Erstellen des Tickets.");
        return;
    });
    const ticket = await response.json();

    window.location.href = `/ticket?ticketID=${ticket.ticket_id}`;
    showSuccessBanner("Ticket wurde erfolgreich erstellt.");
}

document.addEventListener("DOMContentLoaded", loadNavbar);