let ticket;

async function ladeTicketinformationen(){
    const params = new URLSearchParams(window.location.search);
    const ticketId = params.get("ticketId");
    const response = await fetch("/api/tickets?ticket_id=" + ticketId, {
        method: "GET",
        credentials: "include"
    });
    if(!response.ok){
        console.error("Fehler beim Laden des Tickets:", response.status);
        showErrorbanner("Fehler beim Laden des Tickets.");
        return;
    }
    const tickets = await response.json();
    if(tickets.length === 0){
        ticketInfo.innerHTML = "<p>Kein Ticket gefunden.</p>";
        return;
    }
    ticket = tickets[0];    
}



async function ladeTicketKopf(){
    const ticketInfo = document.getElementById("ticket-info");
    
    const kunden = document.getElementById("kunden-auswahl");
    const ersteller = document.getElementById("ersteller");
    const beschreibung = document.getElementById("beschreibung-eingabefeld");
    const bearbeiter = document.getElementById("bearbeiter-auswahl");
    const cc = document.getElementById("cc-auswahl");
    const cc2 = document.getElementById("cc2-auswahl");
    const cc3 = document.getElementById("cc3-auswahl");
    const status = document.getElementById("ticket-status-auswahl");
    const stunden = document.getElementById("ticket-stunden");
    const anhang = document.getElementById("ticket-anhang");
    ticketInfo.innerHTML = "";

    const {year, month, day, hours, minutes, seconds} = splitSQLDateTime(ticket.erstellt);
    const erstellDatum = day + "." + month + "." + year;
    const erstellZeit = hours + ":" + minutes + " Uhr";
    ticketInfo.innerHTML = `
        <p><strong>Ticket #${ticket.erp_ticketnr === null ? "Ausstehend" : ticket.erp_ticketnr}</strong></p>
        <p>erstellt am</p>
        <p>${erstellDatum}</p>
        <p>${erstellZeit}</p>
    `;
    kunden.value = ticket.kunde || "-";
    ticketInfo.dataset.kunde = ticket.kunde || "";
    ersteller.textContent = ticket.ersteller_vorname + " " + ticket.ersteller_nachname || "Unbekannt";
    beschreibung.value = ticket.beschreibung || "";
    bearbeiter.value = ticket.bearbeiter || "-";
    cc.value = ticket.cc || "-";
    cc2.value = ticket.cc2 || "-";
    cc3.value = ticket.cc3 || "-";
    status.value = ticket.status;
}

async function ladeKunden(){
    const kundenauswahl = document.getElementById("kunden-auswahl");
    kundenauswahl.innerHTML = "";
    const leereoption = document.createElement("option");
    leereoption.value = "";
    leereoption.textContent = "-";
    kundenauswahl.appendChild(leereoption);
    const response = await fetch("/api/kunden", {
        method: "GET",
        credentials: "include"
    });
    if(!response.ok){
        console.error("Fehler beim Laden der Kunden:", response.status);
        showErrorbanner("Fehler beim Laden der Kunden.");
        return;
    }
    const kunden = await response.json();
    kunden.forEach(kunde => {
        const option = document.createElement("option");
        option.value = kunde.kunden_id;
        option.textContent = kunde.kunde_name;
        kundenauswahl.appendChild(option);
    });
    kunden.value = ticket.kunde;
}

async function ladeBearbeiter(){
    const bearbeiterauswahl = document.getElementById("bearbeiter-auswahl");
    const ccAuswahl = document.getElementById("cc-auswahl");
    const cc2Auswahl = document.getElementById("cc2-auswahl");
    const cc3Auswahl = document.getElementById("cc3-auswahl");
    bearbeiterauswahl.innerHTML = "";
    ccAuswahl.innerHTML = "";
    cc2Auswahl.innerHTML = "";
    cc3Auswahl.innerHTML = "";
    const leereoption = document.createElement("option");
    leereoption.value = "";
    leereoption.textContent = "-";
    bearbeiterauswahl.appendChild(leereoption);
    ccAuswahl.appendChild(leereoption.cloneNode(true));
    cc2Auswahl.appendChild(leereoption.cloneNode(true));
    cc3Auswahl.appendChild(leereoption.cloneNode(true));
    const response = await fetch("/api/benutzer?kunde=1", {
        method: "GET",
        credentials: "include"
    });
    if(!response.ok){
        console.error("Fehler beim Laden der Bearbeiter:", response.status);
        showErrorbanner("Fehler beim Laden der Bearbeiter.");
        return;
    }
    const benutzer = await response.json();
    benutzer.forEach(user => {
        const option = document.createElement("option");
        option.value = user.benutzer_id;
        option.textContent = user.nachname;
        bearbeiterauswahl.appendChild(option);
        const optionCC = option.cloneNode(true);
        ccAuswahl.appendChild(optionCC);
        const optionCC2 = option.cloneNode(true);
        cc2Auswahl.appendChild(optionCC2);
        const optionCC3 = option.cloneNode(true);
        cc3Auswahl.appendChild(optionCC3);
    });
}

document.addEventListener("DOMContentLoaded", async () => {
    await ladeTicketinformationen();
    await ladeBearbeiter();
    await ladeKunden();
    await ladeTicketKopf();
    ladeStundeneintraege();
});

function splitSQLDateTime(sqlDateTime) {
    if (!sqlDateTime) {
      return { year: null, month: null, day: null, hours: null, minutes: null, seconds: null };
    }
  
    const date = new Date(sqlDateTime);
  
    return {
      year: date.getUTCFullYear(),
      month: String(date.getUTCMonth() + 1).padStart(2, "0"),
      day: String(date.getUTCDate()).padStart(2, "0"),
      hours: String(date.getUTCHours()).padStart(2, "0"),
      minutes: String(date.getUTCMinutes()).padStart(2, "0"),
      seconds: String(date.getUTCSeconds()).padStart(2, "0"),
    };
}

document.getElementById("kunden-auswahl").addEventListener("change", async (event) => {
    const neuerKunde = event.target.value;
    await fetch("/api/tickets", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticketId: ticket.ticket_id, field: "kunde", value: neuerKunde })
    });
});

document.getElementById("beschreibung-eingabefeld").addEventListener("blur", async (event) => {
    const neueBeschreibung = event.target.value;
    await fetch("/api/tickets", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticketId: ticket.ticket_id, field: "beschreibung", value: neueBeschreibung })
    });
});

document.getElementById("bearbeiter-auswahl").addEventListener("change", async (event) => {
    const neuerBearbeiter = event.target.value;
    await fetch("/api/tickets", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticketId: ticket.ticket_id, field: "bearbeiter", value: neuerBearbeiter })
    });
});

document.getElementById("cc-auswahl").addEventListener("change", async (event) => {
    const neuerCC = event.target.value;
    await fetch("/api/tickets", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticketId: ticket.ticket_id, field: "cc", value: neuerCC })
    });
});

document.getElementById("cc2-auswahl").addEventListener("change", async (event) => {
    const neuerCC2 = event.target.value;
    await fetch("/api/tickets", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticketId: ticket.ticket_id, field: "cc2", value: neuerCC2 })
    });
});

document.getElementById("cc3-auswahl").addEventListener("change", async (event) => {
    const neuerCC3 = event.target.value;
    await fetch("/api/tickets", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticketId: ticket.ticket_id, field: "cc3", value: neuerCC3 })
    });
});

document.getElementById("ticket-status-auswahl").addEventListener("change", async (event) => {
    const neuerStatus = event.target.value;
    try {
        await fetch("/api/tickets", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ticketId: ticket.ticket_id, field: "status", value: neuerStatus })
        });
    } catch (error) {
        console.error("Fehler beim Aktualisieren des Ticket-Status:", error);
        showErrorbanner("Fehler beim Aktualisieren des Ticket-Status.");
    }
});