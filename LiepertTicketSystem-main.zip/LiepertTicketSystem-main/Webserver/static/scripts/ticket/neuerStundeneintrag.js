document.getElementById("neuerStundeneintrag").addEventListener("click", neuerStundeneintrag);

async function neuerStundeneintrag() {
    let neuerEintragResponse;
    const params = new URLSearchParams(window.location.search);
    const ticketId = params.get("ticketId");
    console.log("Erstelle neuen Stundeneintrag für Ticket ID:", ticketId);
    try{
        const mitarbeiterResponse = await fetch('/me');
        if(!mitarbeiterResponse.ok){
            console.log(mitarbeiterResponse);
            showErrorbanner("Fehler beim Erstellen des neuen Stundeneintrags");
            return;
        }
        const mitarbeiterArr = await mitarbeiterResponse.json();
        const mitarbeiter = mitarbeiterArr.benutzer_id;
        console.log("Mitarbeiter ID für Stundeneintrag:", mitarbeiterArr);
        neuerEintragResponse = await fetch(`/api/stundeneintrag?ticket_id=${ticketId}&mitarbeiter=${mitarbeiter}&datum=${new Date().toISOString().split('T')[0]}&bis=${rundeAktuelleZeitAufViertelstunde()}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "include"
        });
        console.log("Eintrag erstellt");
    } catch (error) {
        console.log(error);
        showErrorbanner("Fehler beim Erstellen des neuen Stundeneintrags");
        return;
    }
    if(!neuerEintragResponse.ok){
        console.log(neuerEintragResponse);
        showErrorbanner("Fehler beim Erstellen des neuen Stundeneintrags");
        return;
    }
    
    window.location.reload();
}

function rundeAktuelleZeitAufViertelstunde() {
    const jetzt = new Date();
    let minuten = jetzt.getMinutes();

    // Minuten auf 0, 15, 30 oder 45 runden
    const gerundet = Math.round(minuten / 15) * 15;
    if (gerundet === 60) {
        jetzt.setHours(jetzt.getHours() + 1);
        minuten = 0;
    } else {
        minuten = gerundet;
    }

    const stunden = jetzt.getHours().toString().padStart(2, "0");
    const min = minuten.toString().padStart(2, "0");
    const sec = "00";

    return `${stunden}:${min}:${sec}`;
}