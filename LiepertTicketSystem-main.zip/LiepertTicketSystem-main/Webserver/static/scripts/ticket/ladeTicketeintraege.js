let ticketeintraege = [];

async function ladeStundeneintraege(){
    const ticketInfo = document.getElementById("ticket-info");
    //const ticketId = ticketInfo.dataset.id;
    const params = new URLSearchParams(window.location.search);
    const ticketId = params.get("ticketId");
    const container = document.getElementById('stundeneintraege');
    
    const response = await fetch(`/api/stundeneintrag?ticketid=${ticketId}`);
    if(!response.ok){
        console.log(response);
        showErrorbanner("Fehler beim Laden der Ticketeinträge");
        return;
    }
    ticketeintraege = await response.json();

    const autoResponse = await fetch('/api/fahrzeuge');
    if(!autoResponse.ok){
        console.log(autoResponse);
        showErrorbanner("Fehler beim Laden der Fahrzeugdaten");
        return;
    }
    const fahrzeuge = await autoResponse.json();

    const listContainer = document.getElementById('stundeneintraege');
    //listContainer.innerHTML = '';
    for (const ticketeintrag of ticketeintraege) {
        const url = `/api/projekte?kunde=${ticketInfo.dataset.kunde}&datum=${ticketeintrag.datum}`;
        let projekteResponse;
        try{
            projekteResponse = await fetch(url);
        } catch (error) {
            console.error("Fehler beim Laden der Projekte:", error);
            showErrorbanner("Fehler beim Laden der Projekte");
            return;
        }
        if(!projekteResponse.ok){
            console.log(projekteResponse);
            showErrorbanner("Fehler beim Laden der Projekte");
            return;
        }
        const projekte = await projekteResponse.json();
        ticketeintrag.projekte = projekte;
        ticketeintrag.fahrzeuge = fahrzeuge;
        const stundeneintragContainer = document.createElement('div');
        listContainer.append(createStundeneintrag(ticketeintrag, stundeneintragContainer));
        setTimeout(() => {
            const select = document.getElementById(`stundeneintrag-stundenart${ticketeintrag.std_id}`);
            //const autoselect = document.getElementById();
            if (select) select.value = ticketeintrag.Art;
        }, 0);
        container.appendChild(stundeneintragContainer);
    }

    // Änderungen an beliebigem Feld abfangen
    listContainer.addEventListener('blur', handleChange);
    listContainer.addEventListener('change', handleChange);

    async function handleChange(event) {
        const el = event.target;
        const field = el.dataset.field;
        const container = el.closest(".stundeneintrag");
        const parent = el.closest('.stundeneintrag');
        const id = parent.dataset.id;
        if (!field) return; // kein relevantes Feld
        if(field === "vorort"){
            if (!container) return;
            const vorOrtDiv = container.querySelector(".stundeneintrag-vororteinstellungen");
            if (!vorOrtDiv) return;
            const projekt = container.querySelector(".stundeneintrag-projekt");
            const projektId = projekt.value;
            if(projektId === ""){
                projekt.style.border = "2px solid red";
                showErrorbanner("Bitte zuerst ein Projekt auswählen, um Fahrzeit und Kilometer zu laden.");
                el.checked = false;
                return;
            }

            

            // ein- oder ausblenden
            vorOrtDiv.style.display = el.checked ? "block" : "none";
            //TODO: Fahrzeit und Kilometer müssen anhand des Projekts gesetzt werden
            
            const fahrzeitInput = container.querySelector(".stundeneintrag-fahrzeit");
            const fahrstreckeInput = container.querySelector(".stundeneintrag-fahrstrecke");
            try{
                document.body.style.cursor = "wait";
                const projektResponse = await fetch(`/api/projekte?projektId=${projektId}`);
                if(!projektResponse.ok){
                    console.log(projektResponse);
                    showErrorbanner("Fehler beim Laden der Projektfahrzeit");
                    document.body.style.cursor = "default";
                    return;
                }
                const projektData = await projektResponse.json();
                if(projektData.length === 0){
                    showErrorbanner("Projekt nicht gefunden");
                    document.body.style.cursor = "default";
                    return;
                }
                const projekt = projektData[0];
                fahrzeitInput.value = projekt.FAHRZEIT;
                fahrstreckeInput.value = projekt.KM_ORT;
                //TODO: Request kommt nicht zurück
                fetch('/api/stundeneintrag', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        id: id, 
                        field: "fahrzeit", 
                        value: projekt.FAHRZEIT
                    })
                });
                fetch('/api/stundeneintrag', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        id: id,
                        field: "KM",
                        value: projekt.KM_ORT
                    })
                });
                document.body.style.cursor = "default";
            } catch (error) {
                console.error("Fehler beim Laden der Projektfahrzeit:", error);
                showErrorbanner("Fehler beim Laden der Projektfahrzeit");
                document.body.style.cursor = "default";
                return;
            }
        }
        if(field === "projekt"){
            const projektId = el.value;
            const fahrzeitInput = container.querySelector(".stundeneintrag-fahrzeit");
            fahrzeitInput.dataset.projektId = projektId;
            el.style.border = "";
        }
            

        

        let value;
        if (el.type === 'checkbox') {
            value = el.checked;
        } else {
            value = el.value;
        }

        await fetch('/api/stundeneintrag', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, field, value })
        });
        console.log(`Gespeichert: ${id} → ${field} = ${value}`);
    }
}

function druckeTicket() {
    if (!ticket || ticketeintraege.length === 0) {
        showErrorbanner("Keine Ticketeinträge oder Ticketdaten verfügbar.");
        return;
    }
    

    const iframe = document.createElement("iframe");
    iframe.style.position = "fixed";
    iframe.style.right = "0";
    iframe.style.bottom = "0";
    iframe.style.width = "0";
    iframe.style.height = "0";
    iframe.style.border = "0";

    document.body.appendChild(iframe);

    const doc = iframe.contentWindow.document;
    console.log(ticket, ticketeintraege);
    doc.open();
    doc.write(`
        <html>
        <head>
            <title>Ticket #${ticket.ticket_id} - Druckansicht</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                h1 { font-size: 20px; margin-bottom: 10px; }
                h2 { margin-top: 20px; font-size: 16px; }
                table { width: 100%; border-collapse: collapse; margin-top: 10px; }
                th, td { border: 1px solid #ccc; padding: 6px; text-align: left; }
                th { background-color: #f0f0f0; }
                .header { margin-bottom: 20px; }
            </style>
        </head>
        <body>
            <img src="../img/LOGO_ho.png" alt="Liepert Logo" style="height: 50px; position: fixed; top: 0; right: 20px;">
            <div class="header">
                <h1>Ticket #${ticket.ticket_id}: ${ticket.beschreibung || ""}</h1>
                <p><strong>Kunde:</strong> ${ticket.kunde_name || "Unbekannt"}</p>
                <p><strong>Erstellt am:</strong> ${new Date(ticket.erstellt).toLocaleDateString()}</p>
                <p><strong>Bearbeiter:</strong> ${ticket.bearbeiter_vorname + " " + ticket.bearbeiter_nachname || "-"}</p>
            </div>

            <h2>Ticketeinträge</h2>
            <table>
                <thead>
                    <tr>
                        <th>Datum</th>
                        <th>Techniker</th>
                        <th>Beschreibung</th>
                        <th>Dauer</th>
                    </tr>
                </thead>
                <tbody>
                    ${ticketeintraege[0].map(e => `
                        <tr>
                            <td>${wandleDatum(e.datum)}</td>
                            <td>${e.Mitarbeiter_vorname + " " + e.Mitarbeiter_nachname || "-"}</td>
                            <td>${(e.Leistung || "").replace(/\n/g, "<br>")}</td>
                            <td>${e.Zeitvon + " - " + e.Zeitbis + " (" + e.Zeit + "h)" || ""}</td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        </body>
        </html>
    `);
    doc.close();

    iframe.onload = function () {
        iframe.contentWindow.focus();
        iframe.contentWindow.print();

        setTimeout(() => iframe.remove(), 1000);
    };
}

function wandleDatum(datum) {
    const [jahr, monat, tag] = datum.split("-");
    return `${tag}.${monat}.${jahr}`;
}

function createStundeneintrag(ticketeintrag, container) {
    container.classList.add('stundeneintrag');
    container.dataset.id = ticketeintrag.std_id;
    container.innerHTML = `
        <div class="stundeneintrag-info">
            <input type="date" data-field="datum" value="${sqlDateTimeToDisplay(ticketeintrag.datum)}">
            <p data-field="ersteller">${ticketeintrag.Mitarbeiter_vorname} ${ticketeintrag.Mitarbeiter_nachname}</p>
            <div class="stundeneintrag-uhrzeiten">
                <input type="time" data-field="Zeitvon" value="${ticketeintrag.Zeitvon || ticketeintrag.Zeitbis}"> &nbsp;-&nbsp;
                <input type="time" data-field="Zeitbis" value="${ticketeintrag.Zeitbis}"> Uhr
            </div>
        </div>

        <div class="stundeneintrag-regiebericht">
            <p>Regiebericht</p>
            <textarea class="beschreibung-eingabefeld" data-field="Leistung">${ticketeintrag.Leistung  || ""}</textarea>
        </div>

        <div>
            <label>Stundeneintrag</label><br>
            <input type="checkbox" data-field="stundenbuchung" ${ticketeintrag.stundenbuchung ? "checked" : ""}><br><br>
            <label>Für Kunden sichtbar</label><br>
            <input type="checkbox" data-field="kundensichtbarkeit" ${ticketeintrag.kundensichtbarkeit ? "checked" : ""}>
        </div>

        <div class="stundeneintrag-projektinfo">
            <p>Projekt</p>
            <select class="stundeneintrag-projekt" type="text" data-field="projekt" value="${ticketeintrag.projekt_name || ""}">
                <option value=""> - </option>
                ${ticketeintrag.projekte.map(projekt => `
                    <option value="${projekt.lfdnrPRJ}" ${ticketeintrag.projekt == projekt.lfdnrPRJ ? "selected" : ""}>${projekt.PRJ} | ${projekt.kunde_name}</option>
                `).join('')}
            </select>
            <br>
            <div class="stundenart">
                <p>Std. Art</p>
                <select data-field="art">
                    <option value="0"> - </option>
                    <option value="1" ${ticketeintrag.stundenart === "1" ? "selected" : ""}>Standard Service</option>
                    <option value="2" ${ticketeintrag.stundenart === "2" ? "selected" : ""}>Server, Router, Firewall, TK</option>
                    <option value="prg" ${ticketeintrag.stundenart === "prg" ? "selected" : ""}>Programmierung</option>
                    <option value="dsb" ${ticketeintrag.stundenart === "dsb" ? "selected" : ""}>Datenschutzberatung</option>
                    <option value="ber" ${ticketeintrag.stundenart === "ber" ? "selected" : ""}>Beratung</option>
                    <option value="int" ${ticketeintrag.stundenart === "int" ? "selected" : ""}>Nur interne Stunden</option>
                </select>
            </div>
        </div>

        <div class="stundeneintrag-zeiteinstellungen">
            <p>Zeiten</p>
            <div>
                <label>Zeit</label>
                <input type="number" step="0.25" data-field="Zeit" value="${ticketeintrag.Zeit || ""}">h
            </div><br>
            <div>
                <label>o.B.</label>
                <input type="number" step="0.25" data-field="Zeit_OB" value="${ticketeintrag.Zeit_OB || ""}">h
            </div><br>
            <div>
                <label>Vor Ort</label>
                <input type="checkbox" data-field="vorort" ${ticketeintrag.vorort ? "checked" : ""}>
            </div>
        </div>

        <div class="stundeneintrag-vororteinstellungen" ${ticketeintrag.vorort ? '' : 'style="display: none;"'}>
            <p>Fahrzeit</p>
            <input class="stundeneintrag-fahrzeit" type="number" data-field="fahrzeit" data-projektId="${ticketeintrag.projekt || ""}" value="${ticketeintrag.FAHRZEIT || ""}">h <br><br>
            <input class="stundeneintrag-fahrstrecke" type="number" data-field="KM" value="${ticketeintrag.KM || ""}">km <br><br>
            <select class="fahrzeug_select" data-field="Fahrzeug">
                <option value=""> - </option>
                ${ticketeintrag.fahrzeuge.map(fahrzeug => `
                    <option value="${fahrzeug.fahrzeug_id}" ${ticketeintrag.Fahrzeug == fahrzeug.fahrzeug_id ? "selected" : ""}>${fahrzeug.fahrzeug_id} | ${fahrzeug.KfzKZ} | ${fahrzeug.Modell}</option>
                `).join('')}
            </select>
        </div>
    `;

    const inputVon = container.querySelector('input[data-field="Zeitvon"]');
    const inputBis = container.querySelector('input[data-field="Zeitbis"]');
    const inputZeit = container.querySelector('input[data-field="Zeit"]');

    function updateZeit() {
        const von = inputVon.value;
        const bis = inputBis.value;

        if (von && bis) {
            const ergebnis = berechneTicketGesamtzeit(von, bis);
            inputZeit.value = ergebnis;
        }
    }

    inputVon.addEventListener('change', updateZeit);
    inputBis.addEventListener('change', updateZeit);

    const selectStundenart = container.querySelector('select[data-field="art"]');
    selectStundenart.value = ticketeintrag.Art || "0";

    return container;
}

const listContainer = document.getElementById('stundeneintraege');

function sqlDateTimeToDisplay(sqlDateTime) {
    if (!sqlDateTime) return "";
    const datePart = sqlDateTime.split("T")[0];

    let [year, month, day] = datePart.split("-");
    if (!year || !month || !day) return "";
    return `${year}-${month}-${day}`;
}


document.getElementById("ticket-drucken").addEventListener("click", druckeTicket);


function berechneTicketGesamtzeit(Zeitvon, Zeitbis) {
    let gesamtzeit = 0;
    if (Zeitvon && Zeitbis) {
        const [vonStunden, vonMinuten] = Zeitvon.split(":").map(Number);
        const [bisStunden, bisMinuten] = Zeitbis.split(":").map(Number);
        gesamtzeit = (bisStunden + bisMinuten / 60) - (vonStunden + vonMinuten / 60);
        if (gesamtzeit < 0) gesamtzeit += 24; // Über Mitternacht
    }
    return gesamtzeit;
}