const passwordField = document.getElementById("login_password");
const emailField = document.getElementById("login_mail");

async function loginToSoftware(){
    const email = emailField.value;
    const password = passwordField.value;
    if(!email){
        showErrorbanner("Bitte E-Mail Adresse angeben");
        emailField.style.borderColor = "var(--failed-color)";
        return;
    }
    if(!password){
        showErrorbanner("Bitte Passwort angeben");
        passwordField.style.borderColor = "var(--failed-color)";
        return;
    }

    try {
        const response = await fetch("/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: email, password: password }),
            credentials: "include"
        });

        if (response.status === 401) {
            console.log(response.json.details);
            return showErrorbanner("Benutzername oder Passwort falsch");
        }

        if (!response.ok) {
            console.log(response.json.details);
            return showErrorbanner("Anmeldung fehlgeschlagen");
        }

        // Wenn Login erfolgreich war, wird das Cookie automatisch vom Server gesetzt
        // -> HttpOnly Cookie kann nicht per JS ausgelesen werden
        window.location.href = "/";
    } catch (err) {
        console.error(err);
        alert("Anmeldung fehlgeschlagen");
    }
}

function showErrorbanner(message){
    const banner = document.createElement("div");
    banner.textContent = message;
    banner.style.position = "fixed";
    banner.style.top = "10px";
    banner.style.left = "50%";
    banner.style.transform = "translateX(-50%)";
    banner.style.backgroundColor = "var(--failed-color)";
    banner.style.color = "var(secondary-text)";
    banner.style.padding = "10px 20px";
    banner.style.borderRadius = "5px";
    banner.style.boxShadow = "0px 4px 6px var(--shadow-heavy)";
    banner.style.zIndex = "1000";

    document.body.appendChild(banner);

    setTimeout(() => {
        banner.remove();
    }, 3000);
}

document.getElementById("login_button").addEventListener("click", loginToSoftware);

emailField.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        loginToSoftware();
    }
});

passwordField.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        loginToSoftware();
    }
});

emailField.addEventListener("click", () => resetBorderColor("login_mail"));
passwordField.addEventListener("click", () => resetBorderColor("login_password"));

function resetBorderColor(fieldId) {
    const field = document.getElementById(fieldId);
    field.style.borderColor = "";
}
