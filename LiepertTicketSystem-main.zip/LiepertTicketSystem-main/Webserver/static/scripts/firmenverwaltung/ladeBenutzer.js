async function ladeBenutzer(){
    let response = await fetch('/api/benutzer');
    if(!response.ok){
        console.error("Fehler beim Laden der Benutzer" + response.details);
        showErrorbanner("Fehler beim Laden der Benutzer");
        return;
    }
    let benutzer = await response.json();
    if(benutzer.length === 0){
        const table = document.getElementById("firmenbenutzer_tabelle_body");
        const row = table.insertRow();
        const cell = row.insertCell(0);
        cell.colSpan = 4;
        cell.textContent = "Keine Benutzer gefunden.";
        cell.style.textAlign = "center";
        return;
    }
    const tableBody = document.getElementById("firmenbenutzer_tabelle_body");
    tableBody.innerHTML = '';
    benutzer.forEach((user) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${user.vorname} ${user.nachname}</td>
            <td>${user.email}</td>
            <td>${user.rolle}</td>
        `;
        const edit = document.createElement("td");
        edit.style.textAlign = "right";
        const editButton = document.createElement("button");
        editButton.className = "bearbeiten-button";
        const editIcon = document.createElement("img");
        editIcon.src = "./img/edit_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg";
        editIcon.alt = "Bearbeiten";
        editIcon.className = "icon-small";
        editButton.appendChild(editIcon);
        editButton.addEventListener("click", () => {
            openFirmenverwaltungBenutzerModal(user.benutzer_id, user.vorname, user.nachname, user.email, user.rolle, user.kunde_name);
        });
        edit.appendChild(editButton);

        const deleteButton = document.createElement("button");
        deleteButton.className = "loeschen-button";
        const deleteIcon = document.createElement("img");
        deleteIcon.src = "./img/delete_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg";
        deleteIcon.alt = "Löschen";
        deleteIcon.className = "icon-small";
        deleteButton.appendChild(deleteIcon);
        deleteButton.addEventListener("click", async () => {
            if(confirm(`Möchten Sie den Benutzer ${user.vorname} ${user.nachname} wirklich löschen?`))
                loescheBenutzer(user.benutzer_id);
        });
        edit.appendChild(deleteButton);

        row.appendChild(edit);
        tableBody.appendChild(row);
    });
    const button_reihe = document.createElement("tr");
    const button_zelle = document.createElement("td");
    button_zelle.id = "benutzer_hinzufuegen_zelle";
    button_zelle.colSpan = 4;
    button_zelle.style.textAlign = "center";
    const addButton = document.createElement("button");
    addButton.id = "benutzer_hinzufuegen_button";
    addButton.innerHTML = `
        <img src="../../img/add_circle_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg" alt="" class="icon-small">
        Benutzer hinzufügen
    `;
    button_zelle.appendChild(addButton);
    button_reihe.appendChild(button_zelle);
    tableBody.appendChild(button_reihe);
    addButton.addEventListener("click", () => {
        openFirmenverwaltungBenutzerModal(null, "", "", "", "user", "");
    });
}

document.addEventListener("DOMContentLoaded", () => {
    ladeBenutzer();
});

async function openFirmenverwaltungBenutzerModal(id, vorname, nachname, email, rolle, kunde_name){
    document.getElementById("benutzer_bearbeiten_popup").style.display = "flex";
    const vorname_input = document.getElementById("benutzer_vorname_input");
    const nachname_input = document.getElementById("benutzer_nachname_input");
    const email_input = document.getElementById("benutzer_email_input");
    const rolle_input = document.getElementById("benutzer_rolle_select");
    const passwort_input = document.getElementById("benutzer_passwort_input");
    vorname_input.value = vorname;
    nachname_input.value = nachname;
    email_input.value = email;
    rolle_input.value = rolle;
    passwort_input.value = "";

    const response = await fetch("/me", {
        method: "GET",
        credentials: "include"
    });

    if(!response.ok) {
        console.error("Failed to fetch user data");
        showErrorbanner("Fehler beim Laden der Benutzerdaten");
        return;
    }

    const userData = await response.json();
    const ersteller = userData.benutzer_id;
    const kunde = userData.kunde;
    console.log(userData);
    const systemadmin = document.createElement("option");
    systemadmin.value = "Systemadministrator";
    systemadmin.text = "Systemadministrator";
    document.getElementById("benutzer_rolle_select").appendChild(systemadmin);

    document.getElementById("speichern_neuer_benutzer").addEventListener("click", () => {
        vorname = vorname_input.value.trim();
        nachname = nachname_input.value.trim();
        email = email_input.value.trim();
        rolle = rolle_input.value;
        const passwort = passwort_input.value;
    
        if(id === null) erstelleBenutzer(vorname, nachname, email, rolle, passwort, kunde, ersteller);
        else updateBenutzer(id, vorname, nachname, email, rolle, passwort);
    });
}

async function erstelleBenutzer(vorname, nachname, email, rolle, passwort, kunde, ersteller){
    let url = `
        /api/benutzer?vorname=${encodeURIComponent(vorname)}&nachname=${encodeURIComponent(nachname)}&e_mail=${encodeURIComponent(email)}&rolle=${encodeURIComponent(rolle)}&kunde=${encodeURIComponent(kunde)}&ersteller=${encodeURIComponent(ersteller)}&kuerzel=${encodeURIComponent(vorname.charAt(0) + nachname.charAt(0))}&aktiv=1`;
    if(passwort && passwort.length > 0) url += `&passwort=${encodeURIComponent(passwort)}`;
    console.log(url);
    await fetch(url, {
        method: 'POST'
    }).then(response => {
        if(!response.ok){
            console.error("Fehler beim Erstellen des Benutzers" + response.details);
            showErrorbanner("Fehler beim Erstellen des Benutzers");
            return;
        }
        ladeBenutzer();
    }).catch(error => {
        console.error("Fehler beim Erstellen des Benutzers", error);
        showErrorbanner("Fehler beim Erstellen des Benutzers");
    });
}

async function updateBenutzer(id, vorname, nachname, email, rolle, passwort){
    let url = `/api/benutzer?benutzer_id=${id}`;
    console.log(id);
    if(passwort && passwort.length > 0) url += `&passwort=${encodeURIComponent(passwort)}`;
    if(rolle) url += `&rolle=${encodeURIComponent(rolle)}`;
    if(vorname) url += `&vorname=${encodeURIComponent(vorname)}`;
    if(nachname) url += `&nachname=${encodeURIComponent(nachname)}`;
    if(email) url += `&email=${encodeURIComponent(email)}`;

    await fetch(url, {
        method: 'PUT'
    }).then(response => {
        if(!response.ok){
            console.error("Fehler beim Aktualisieren des Benutzers" + response.details);
            showErrorbanner("Fehler beim Aktualisieren des Benutzers");
            return;
        }
        ladeBenutzer();
    }).catch(error => {
        console.error("Fehler beim Aktualisieren des Benutzers", error);
        showErrorbanner("Fehler beim Aktualisieren des Benutzers");
    });
}

async function loescheBenutzer(id){
    await fetch(`/api/benutzer?benutzer_id=${id}&aktiv=0`, {
        method: 'PUT'
    }).then(response => {
        if(!response.ok){
            console.error("Fehler beim Löschen des Benutzers" + response.details);
            showErrorbanner("Fehler beim Löschen des Benutzers");
            return;
        }
    }).catch(error => {
        console.error("Fehler beim Löschen des Benutzers", error);
        showErrorbanner("Fehler beim Löschen des Benutzers");
    });
}


document.getElementById("close_neuer_benutzer").addEventListener("click", () => {
    document.getElementById("benutzer_bearbeiten_popup").style.display = "none";
});

document.addEventListener('click', (event) => {
    const popup = document.getElementById("benutzer_bearbeiten_popup");
    if (event.target === popup) {
        popup.style.display = "none";
    }
});

