async function ladeTickets(benutzerDaten){  
    let url = "/api/tickets";
    if(benutzerDaten.kunde === 1) url += `?bearbeiter=${benutzerDaten.benutzer_id}`;
    if(benutzerDaten.rolle === "firmenadministrator") url += `kunde=${benutzerDaten.kunde}`;
    if(benutzerDaten.rolle === "benutzer") url += `ersteller=${benutzerDaten.benutzer_id}`;

    if(localStorage.getItem("ticketAnsicht") === "geschlossen") url += "&status=geschlossen";

    try{
        const ticketResponse = await fetch(url, {
            method: "GET",
            credentials: "include"
        });

        if(!ticketResponse.ok) {
            throw new Error("Tickets konnten nicht geladen werden: " + ticketResponse.status);
        }
        const tickets = await ticketResponse.json();
        if(tickets.length === 0) {
            const tr = document.createElement("tr");
            tr.innerHTML = `<td colspan="${benutzerDaten.rolle === "techniker" ? 6 : 5}">Keine Tickets vorhanden</td>`;
            const tbody = document.createElement("tbody");
            tbody.appendChild(tr);
            const ticketTabelle = document.getElementById("ticket_tabelle");
            ticketTabelle.appendChild(tbody);
            return;
        }
        erstelleTicketTabelle(tickets, benutzerDaten);

        
    } catch(error){
        console.error("Fehler beim Tickets Laden: " + error);
        const ticketTabelle = document.getElementById("ticket_tabelle");
        ticketTabelle.innerHTML = "";
        const tbody = document.createElement("tbody");
        const tr = document.createElement("tr");
        tr.innerHTML = `<td colspan="${benutzerDaten.rolle === "techniker" ? 7 : 6}">Fehler beim Laden der Tickets</td>`;
        tbody.appendChild(tr);
        ticketTabelle.appendChild(tbody);
    }
}

async function ladeGefilterteTickets(benutzerDaten){
    const suchbegriff = document.getElementById("suche_input").value.trim();
    const kunde = document.getElementById("kunde_input").value.trim();
    const bearbeiter = document.getElementById("bearbeiter_input").value.trim();
    
    let url = `/api/tickets?val=1`;
    if(benutzerDaten.kunde === 1){
        if(suchbegriff) url += `&suchbegriff=${encodeURIComponent(suchbegriff)}`;
        if(kunde) url += `&kunde=${encodeURIComponent(kunde)}`;
        if(bearbeiter) url += `&bearbeiter=${encodeURIComponent(bearbeiter)}`;
    } else if(benutzerDaten.rolle === "firmenadministrator") {
        url += `&kunde=${benutzerDaten.kunde}`;
        if(suchbegriff) url += `&suchbegriff=${encodeURIComponent(suchbegriff)}`;
        if(bearbeiter) url += `&bearbeiter=${encodeURIComponent(bearbeiter)}`;
    } else{
        url += `&ersteller=${benutzerDaten.benutzer_id}`;
        if(suchbegriff) url += `&suchbegriff=${encodeURIComponent(suchbegriff)}`;
        if(bearbeiter) url +=  `&bearbeiter=${encodeURIComponent(bearbeiter)}`;
    }
    if(localStorage.getItem("ticketAnsicht") === "geschlossen") url += "&status=geschlossen";

    const ticketTabelle = document.getElementById("ticket_tabelle");
    try{
        const ticketAntwort = await fetch(url, {
            method: "GET",
            credentials: "include"
        });
        if(!ticketAntwort.ok) {
            throw new Error("Gefilterte Tickets konnten nicht geladen werden: " + ticketAntwort.status);
        }
        const tickets = await ticketAntwort.json();

        erstelleTicketTabelle(tickets, benutzerDaten);
    } catch (error){
        console.error("Fehler beim Laden der gefilterten Tickets: " + error);
        ticketTabelle.innerHTML = "";
        const tbody = document.createElement("tbody");
        const tr = document.createElement("tr");
        tr.innerHTML = `<td colspan="${benutzerDaten.rolle === "techniker" ? 7 : 6}">Fehler beim Laden der Tickets</td>`;
        tbody.appendChild(tr);
        ticketTabelle.appendChild(tbody);
        return;
    }
}

async function ladeGeschlosseneTickets(benutzerDaten){
    const url = benutzerDaten.kunde === 1 ? `/api/tickets?bearbeiter=${benutzerDaten.benutzer_id}&status=geschlossen` : `/api/tickets?ersteller=${benutzerDaten.benutzer_id}&status=geschlossen`;
    try{
        const response = fetch(url, {
            method: "GET",
            credentials: "include"
        })
    } catch(error){
        console.error("Fehler beim Laden der geschlossenen Tickets: " + error);
        const ticketTabelle = document.getElementById("ticket_tabelle");
        ticketTabelle.innerHTML = "";
        const tbody = document.createElement("tbody");
        const tr = document.createElement("tr");
        tr.innerHTML = `<td colspan="${benutzerDaten.rolle === "techniker" ? 7 : 6}">Fehler beim Laden der Tickets</td>`;
        tbody.appendChild(tr);
        ticketTabelle.appendChild(tbody);
    }
}

function erstelleTicketTabelle(tickets, benutzerDaten){
    const ticketTabelle = document.getElementById("ticket_tabelle");
    ticketTabelle.innerHTML = ""; // Clear existing rows
    const thead = document.createElement("thead");
    thead.innerHTML = `
        <tr>
            <th>Nummer</th>
            <th>Beschreibung</th>
            ${benutzerDaten.kunde === 1 ? "<th>Kunde</th>" : ""}
            <th>Bearbeiter</th>
            <th>Letzte Änderung</th>
            <th>Status</th>
            <th></th>
        </tr>
    `
    ticketTabelle.appendChild(thead);

    const tbody = document.createElement("tbody");

    if(tickets.length === 0) {
        const tr = document.createElement("tr");
        tr.innerHTML = `<td colspan="${benutzerDaten.kunde === 1 ? 7 : 6}">Keine Tickets vorhanden</td>`;
        tbody.appendChild(tr);
        ticketTabelle.appendChild(tbody);
        return;
    }

    tickets.forEach(ticket => {
        const row = document.createElement("tr");
        const {year, month, day} = splitSQLDateTime(
            ticket.letzte_bearbeitung === null ? ticket.geaendert : ticket.letzte_bearbeitung
        );

        row.innerHTML = `
            <td>${ticket.erp_ticketnr === null ? "Ausstehend" : ticket.erp_ticketnr}</td>
            <td>${ticket.beschreibung}</td>
            ${benutzerDaten.kunde === 1 ? `<td>${ticket.kunde_name}</td>` : ""}
            <td>${ticket.bearbeiter_nachname}</td> 
            <td>${day + "." + month + "." + year}</td>
            <td>${ticket.status}</td>
            <td><span class="arrow">➔</span></td>
        `;
        row.addEventListener("click", () => {
            window.location.href = `/ticket?ticketId=${ticket.ticket_id}`;
        });
        tbody.appendChild(row);
    });
    ticketTabelle.appendChild(tbody);
}

function splitSQLDateTime(sqlDateTime) {
    if (!sqlDateTime) {
      return { year: null, month: null, day: null, hours: null, minutes: null, seconds: null };
    }
  
    const date = new Date(sqlDateTime);
  
    return {
      year: date.getUTCFullYear(),
      month: String(date.getUTCMonth() + 1).padStart(2, "0"),
      day: String(date.getUTCDate()).padStart(2, "0"),
      hours: String(date.getUTCHours()).padStart(2, "0"),
      minutes: String(date.getUTCMinutes()).padStart(2, "0"),
      seconds: String(date.getUTCSeconds()).padStart(2, "0"),
    };
}