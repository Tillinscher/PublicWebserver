function erstelleButtons(benutzerDaten){
    const buttonContainer = document.getElementById("untere_buttons");
    buttonContainer.innerHTML = ""; // Clear existing buttons
    if(benutzerDaten.kunde === 1){
        const poolButton = document.createElement("button");
        poolButton.textContent = "Ticket-Pool";
        poolButton.id = "btn-ungelesen"
        poolButton.innerHTML = `
            Ticket-Pool
            <span id="btn-ungelesen_badge"></span>
        `;
        poolButton.addEventListener("click", () => {
            const aktuellerWert = document.getElementById("bearbeiter_input").value;
            console.log("Aktueller Wert:", aktuellerWert);
            if(aktuellerWert === "101"){
                document.getElementById("bearbeiter_input").value = benutzerDaten.benutzer_id;
                poolButton.innerHTML = `
                    Ticket-Pool
                    <span id="btn-ungelesen_badge"></span>
                `;
                updateUngelesenBadge();
                //window.location.reload();
            }
            else{
                document.getElementById("bearbeiter_input").value = 101;
                poolButton.textContent = "Persönliche Tickets";
            }
            ladeGefilterteTickets({benutzer_id: 101, rolle: "firmenadministrator", kunde: 1});
        });
        buttonContainer.appendChild(poolButton);

        updateUngelesenBadge();
    }

    const geschlosseneTicketsButton = document.createElement("button");
    geschlosseneTicketsButton.id = "btn-geschlossen"

    if(localStorage.getItem("ticketAnsicht") === "geschlossen")
        geschlosseneTicketsButton.textContent = "Offene Tickets";
    else{
        geschlosseneTicketsButton.textContent = "Geschlossene Tickets";
        localStorage.setItem("ticketAnsicht", "offen");
    }

    geschlosseneTicketsButton.addEventListener("click", () => {
        const aktuellerWert = localStorage.getItem("ticketAnsicht");
        console.log("Aktueller Wert:", aktuellerWert);
        if(aktuellerWert === "geschlossen")
            localStorage.setItem("ticketAnsicht", "offen");
        else
            localStorage.setItem("ticketAnsicht", "geschlossen");
        
        window.location.reload();
    });

    buttonContainer.appendChild(geschlosseneTicketsButton);

}

async function updateUngelesenBadge(){
    const btn = document.getElementById("btn-ungelesen");
    const badge = document.getElementById("btn-ungelesen_badge");
    let anzahl;

    try{
        const response = await fetch('/api/ticketanzahl?bearbeiter=101', {
            method: 'GET',
            credentials: 'include'
        });
    
        if(!response.ok) {
            console.error('Fehler beim Abrufen der ungelesenen Ticketanzahl' + response.status);
            anzahl = 0;
            return;
        } else {
            const data = await response.json();
            anzahl = data[0].ungelesen || 0;
        }
    
        if(!Number.isFinite(anzahl) || anzahl < 0) anzahl = 0;
        const count = Math.floor(anzahl);
    
        const display = (count > 99) ? '99+' : String(count);
        badge.textContent = display;
        badge.setAttribute('data-count', String(count));
    
        // Optional für Screenreader:
        btn.setAttribute('aria-label', 
            count === 0 
                ? 'Ungelesene Nachrichten: keine' 
                : `Ungelesene Nachrichten: ${count}`
        );
    } catch (error) {
        console.error('Fehler beim Abrufen der ungelesenen Ticketanzahl', error);
        badge.textContent = '0';
    }
}

document.addEventListener("DOMContentLoaded", () => {
    setInterval(() => {
        updateUngelesenBadge();
    }, 10000);
});