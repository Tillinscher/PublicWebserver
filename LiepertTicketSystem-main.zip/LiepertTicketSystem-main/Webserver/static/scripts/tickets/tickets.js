let techniker_arr = [];
let kunden_arr = [];

async function loadTicketUebersicht(){
    try {
        const response = await fetch("/me", {
            method: "GET",
            credentials: "include"
        });

        if(!response.ok) {
            console.error("Failed to fetch user data");
            return;
        }
        const userData = await response.json();

        const ueberschrift = `Ticketübersicht`;

        document.getElementById("ticketueberschrift").textContent = ueberschrift;
        erstelleSuchfelder(userData);
        ladeTickets(userData);
        erstelleButtons(userData);
    } catch (error) {
        console.error("Fehler beim Laden der Ticketübersicht: ", error);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    loadTicketUebersicht();
});

async function erstelleSuchfelder(benutzerDaten){
    const container = document.getElementById("suchen_container");
    container.innerHTML = ""; // Clear existing fields
    container.innerHTML = `
        <input type="text" id="suche_input" class="suche_input" placeholder="Suche...">
        <select id="kunde_input" class="suche_input" placeholder="Kunde..."></select>
        <select id="bearbeiter_input" class="suche_input" placeholder="Bearbeiter..."></select>
    `;

    await ladeKundenInSuchfeld(benutzerDaten);
    await ladeBearbeiterInSuchfeld(benutzerDaten);

    if(benutzerDaten.kunde !== 1){
        document.getElementById("bearbeiter_input").value = benutzerDaten.benutzer_id;
    }
    const suche_input = document.getElementById("suche_input");
    const kunde_input = document.getElementById("kunde_input");
    const bearbeiter_input = document.getElementById("bearbeiter_input");
    suche_input.addEventListener("input", () => {
        if(suche_input.value === "" && kunde_input.value === "" && bearbeiter_input.value === ""){
            window.location.reload();
            return;
        }
        ladeGefilterteTickets(benutzerDaten);
    });
    kunde_input.addEventListener("input", () => {
        if(suche_input.value === "" && kunde_input.value === "" && bearbeiter_input.value === ""){
            window.location.reload();
            return;
        }
        ladeGefilterteTickets(benutzerDaten);
    });
    bearbeiter_input.addEventListener("input", () => {
        if(suche_input.value === "" && kunde_input.value === "" && bearbeiter_input.value === ""){
            window.location.reload();
            return;
        }
        ladeGefilterteTickets(benutzerDaten);
    });
}

document.getElementById("ticket_erstellen_button").addEventListener("click", () => {
    openNewTicketModal();
});

async function ladeKundenInSuchfeld(benutzerDaten){
    await fetch('/api/kunden', {
        method: "GET",
        credentials: "include"
    })
    .then(response => response.json())
    .then(kunden => {
        const kunde_input = document.getElementById("kunde_input");
        const defaultOption = document.createElement("option");
        defaultOption.value = "";
        defaultOption.textContent = "Alle Kunden";
        kunde_input.appendChild(defaultOption);
        kunden.forEach(kunde => {
            const option = document.createElement("option");
            option.value = kunde.kunde_id;
            option.textContent = kunde.kunde_name;
            kunde_input.appendChild(option);
            kunden_arr[kunde.kunden_id] = kunde.kunde_name;
        });
    })
    .catch(error => {
        console.error("Fehler beim Laden der Kunden für das Suchfeld: ", error);
    });
}

async function ladeBearbeiterInSuchfeld(benutzerDaten){
    await fetch('/api/benutzer?kunde=1', {
        method: "GET",
        credentials: "include"
    })
    .then(response => response.json())
    .then(benutzer => {
        const bearbeiter_input = document.getElementById("bearbeiter_input");
        const defaultOption = document.createElement("option");
        defaultOption.value = benutzerDaten.benutzer_id;
        defaultOption.textContent = benutzerDaten.vorname + " " + benutzerDaten.nachname + " (Ich)";
        bearbeiter_input.appendChild(defaultOption);
        benutzer.forEach(benutzer => {
            if(benutzer.benutzer_id !== benutzerDaten.benutzer_id){ 
                const option = document.createElement("option");
                option.value = benutzer.benutzer_id;
                option.textContent = benutzer.vorname + " " + benutzer.nachname;
                bearbeiter_input.appendChild(option);
                techniker_arr[benutzer.benutzer_id] = benutzer.vorname + " " + benutzer.nachname;
            }
        });
    })
    .catch(error => {
        console.error("Fehler beim Laden der Bearbeiter für das Suchfeld: ", error);
    });
}