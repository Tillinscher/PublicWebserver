INSERT INTO Benutzer (vorname, nachname, email, passwort, kuerzel, rolle, kunde, is_in_erp) 
VALUES ("Luca", "Tillinger", "lt@liepert.de", "$argon2id$v=19$m=65536,t=3,p=1$1wxdJs3fZ6AG6HTmKnQT0A$QkXIwlI4PJJHlA42KlhA0zh4fKD4ErNNUTclmSM9NYw", "lt", "Systemadministrator", 1, 0);
INSERT INTO Benutzer (vorname, nachname, email, passwort, kuerzel, rolle, kunde, is_in_erp) 
VALUES ("Klaus", "Liepert", "kl@liepert.de", "$argon2id$v=19$m=65536,t=3,p=1$1wxdJs3fZ6AG6HTmKnQT0A$QkXIwlI4PJJHlA42KlhA0zh4fKD4ErNNUTclmSM9NYw", "kl", "Firmenadministrator", 1, 0);
INSERT INTO Benutzer (vorname, nachname, email, passwort, kuerzel, rolle, kunde, is_in_erp) 
VALUES ("Ralf", "Konefal", "rk@liepert.de", "$argon2id$v=19$m=65536,t=3,p=1$1wxdJs3fZ6AG6HTmKnQT0A$QkXIwlI4PJJHlA42KlhA0zh4fKD4ErNNUTclmSM9NYw", "rk", "Techniker", 1, 0);

INSERT INTO Tickets (ersteller, kunde, beschreibung, bearbeiter, cc, cc2, status, ansprechpartner, is_in_erp)
VALUES(1, 4, "Drucker funktioniert nicht", 2, 1, 3, "ungelesen", 3, 0);
INSERT INTO Tickets (ersteller, kunde, beschreibung, bearbeiter, status, ansprechpartner, is_in_erp)
VALUES(1, 4, "Monitor flackert", 1, "ungelesen", 3, 0);
INSERT INTO Tickets (ersteller, kunde, beschreibung, bearbeiter, cc, cc2, status, ansprechpartner, is_in_erp)
VALUES(2, 4, "Programm stürzt beim Drucken ab", 1, 2, 3, "gelesen", 3, 0);

INSERT INTO Projekte (lfdnrPRJ, PRJ, PRJ_ZEIT, Projektleiter, ANGELEGT, interneBemerkung, BEGIN, END, MONATSPRJ, KM_ORT, FAHRZEIT, VORORT)
VALUES ("1001", "12-25", 120, 2, 1, "", "2024-02-01", "2024-04-30", 1, 15, 0.5, 90);
INSERT INTO Projekte (lfdnrPRJ, PRJ, PRJ_ZEIT, Projektleiter, ANGELEGT, interneBemerkung, BEGIN, END, MONATSPRJ, KM_ORT, FAHRZEIT, VORORT)
VALUES ("1002", "12-26", 80, 2, 2, "", "2024-03-01", "2024-05-15", 0, 10, 0.3, 60);
INSERT INTO Projekte (lfdnrPRJ, PRJ, PRJ_ZEIT, Projektleiter, ANGELEGT, interneBemerkung, BEGIN, END, MONATSPRJ, KM_ORT, FAHRZEIT, VORORT)
VALUES ("1003", "12-27", 200, 1, 2, "", "2024-04-01", "2024-08-31", 1, 20, 0.7, 120);
INSERT INTO Projekte (lfdnrPRJ, PRJ, PRJ_ZEIT, Projektleiter, ANGELEGT, interneBemerkung, BEGIN, END, MONATSPRJ, KM_ORT, FAHRZEIT, VORORT)
VALUES ("1004", "12-28", 150, 1, 2, "", "2024-05-01", "2024-09-30", 0, 12, 0.4, 80);

INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3029, "2024-06-01", 1, NULL, 1, "Projektarbeit", "08:00", "12:00", 4.0, 4.0, 1, "Feature Implementierung", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3030, "2024-06-02", 2, NULL, 2, "Support", "09:00", "11:30", 2.5, 2.5, 2, "Issue Resolution", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3031, "2024-06-03", 1, NULL, 3, "Meeting", "10:00", "12:00", 2.0, 2.0, 3, "Client Meeting", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3032, "2024-06-04", 2, NULL, 1, "Projektarbeit", "13:00", "17:00", 4.0, 4.0, 1, "Code Review", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3033, "2024-06-05", 1, NULL, 2, "Support", "08:30", "12:30", 4.0, 4.0, 2, "Bug Fixing", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3034, "2024-06-06", 2, NULL, 3, "Meeting", "14:00", "16:00", 2.0, 2.0, 3, "Team Meeting", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3035, "2024-06-07", 1, NULL, 1, "Projektarbeit", "09:00", "13:00", 4.0, 4.0, 1, "Documentation", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3036, "2024-06-08", 2, NULL, 2, "Support", "10:00", "12:00", 2.0, 2.0, 2, "Customer Support", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3037, "2024-06-09", 1, NULL, 3, "Meeting", "11:00", "13:00", 2.0, 2.0, 3, "Project Planning", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3038, "2024-06-10", 2, NULL, 1, "Projektarbeit", "08:00", "12:00", 4.0, 4.0, 1, "System Design", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3039, "2024-06-11", 1, NULL, 2, "Support", "09:00", "11:00", 2.0, 2.0, 2, "Technical Support", 0, 1, NULL, NULL, NULL);
INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, kundensichtbarkeit, KM, FAHRZEIT, Fahrzeug)
VALUES (3040, "2024-06-12", 2, NULL, 3, "Meeting", "10:00", "12:00", 2.0, 2.0, 3, "Sprint Review", 0, 1, NULL, NULL, NULL);