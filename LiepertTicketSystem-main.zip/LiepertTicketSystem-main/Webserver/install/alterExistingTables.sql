CREATE TABLE IF NOT EXISTS Kunden(
    kunden_id INT PRIMARY KEY,
    erp_lfdnr INT,
    kunde_name text,
    kunde_kuerzel varchar(8),
    kundenbetreuer INT,
    erstellt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_kunden_betreuer FOREIGN KEY (kundenbetreuer) REFERENCES Benutzer(benutzer_id)
);

INSERT INTO Kunden (kunden_id, erp_lfdnr, kunde_name, kunde_kuerzel, kundenbetreuer) VALUES (1, NULL, 'it.liepert.gmbh', '', NULL);

ALTER TABLE Benutzer ADD CONSTRAINT fk_kunde_benutzer FOREIGN KEY (kunde) REFERENCES Kunden(kunden_id);

ALTER TABLE TICKETS ADD CONSTRAINT fk_kunde_ticket FOREIGN KEY (kunde) REFERENCES Kunden(kunden_id);

ALTER TABLE Stundeneintraege ADD is_in_erp TINYINT(1) DEFAULT 0;

ALTER TABLE Projekte ADD erstellt TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE Projekte ADD geaendert TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE Kunden ADD geaendert TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

INSERT INTO Benutzer (benutzer_id, ersteller, vorname, nachname, email, passwort, kuerzel, rolle, letzte_aktion, kunde, is_in_erp, aktiv) 
VALUES (100, NULL, 'Connector', '', 'connector@liepert.de', '$argon2id$v=19$m=65536,t=3,p=1$w3qWJxjiypfkLLmoLZz+Fw$orBWaO8UGpNVnUvAvaks2KQJtvqsT+6ouhw1e99E3Ew', 'CNCT', 'connector', NULL, 1, 1, 1);

INSERT INTO Benutzer (benutzer_id, ersteller, vorname, nachname, email, passwort, kuerzel, rolle, letzte_aktion, kunde, is_in_erp, aktiv) 
VALUES (101, NULL, 'Pool', '', 'pool@liepert.de', '', 'POOL', 'pool', NULL, 1, 1, 1);

ALTER TABLE Stundeneintraege MODIFY COLUMN Zeitvon TIME;
ALTER TABLE Stundeneintraege MODIFY COLUMN Zeitbis TIME;

ALTER TABLE Stundeneintraege RENAME COLUMN kundensichtbarleit TO kundensichtbarkeit;

INSERT INTO Fahrzeuge (fahrzeug_id, KfzKZ, Modell)
VALUES
    (1, 'MM IT 123', 'VW Golf'),
    (2, 'MM IT 456', 'Audi A4'),
    (3, 'MM IT 789', 'BMW 3er'),
    (4, 'MM IT 321', 'Mercedes C-Klasse'),
    (5, 'MM IT 654', 'Ford Focus');


ALTER TABLE Fahrzeuge MODIFY Modell TEXT;

INSERT INTO kunden(kunden_id, kunde_name, kunde_kuerzel, kundenbetreuer)
VALUES
    (3, 'Baustoffwerke Gebhart und Söhne', 'KBH', 102),
    (4, 'Ematec AG', 'Ematec', 13),
    (5, 'Beck und Söhne GmbH', 'Beck', 14);