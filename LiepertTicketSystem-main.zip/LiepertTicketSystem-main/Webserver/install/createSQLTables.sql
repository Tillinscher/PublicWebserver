CREATE TABLE IF NOT EXISTS Benutzer (
    benutzer_id INT PRIMARY KEY AUTO_INCREMENT,
    erstellt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    geaendert TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    ersteller INT,
    vorname varchar(64),
    nachname varchar(64),
    email VARCHAR(255) NOT NULL,
    passwort TEXT NOT NULL,
    kuerzel VARCHAR(5),
    rolle VARCHAR(20),
    letzte_aktion DATETIME,
    kunde INT,
    is_in_erp TINYINT(1),
    aktiv TINYINT(1),
    CONSTRAINT fk_ersteller_benutzer FOREIGN KEY (ersteller) REFERENCES Benutzer(benutzer_id)
);

CREATE TABLE IF NOT EXISTS Tickets (
    ticket_id INT PRIMARY KEY AUTO_INCREMENT,
    erp_ticketnr INT,
    erstellt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    geaendert TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    ersteller INT,
    kunde INT,
    beschreibung TEXT,
    termin DATE,
    bearbeiter INT,
    cc INT,
    cc2 INT,
    cc3 INT,
    status VARCHAR(32),
    gelesen DATETIME,
    erledigt DATETIME,
    angebot INT,
    ansprechpartner INT,
    is_in_erp TINYINT(1),
    CONSTRAINT fk_ersteller_ticket FOREIGN KEY (ersteller) REFERENCES Benutzer(benutzer_id),
    CONSTRAINT fk_kunde_ticket FOREIGN KEY (kunde) REFERENCES Kunde(kunden_id),
    CONSTRAINT fk_bearbeiter_ticket FOREIGN KEY (bearbeiter) REFERENCES Benutzer(benutzer_id),
    CONSTRAINT fk_cc_ticket FOREIGN KEY (cc) REFERENCES Benutzer(benutzer_id),
    CONSTRAINT fk_cc2_ticket FOREIGN KEY (cc2) REFERENCES Benutzer(benutzer_id),
    CONSTRAINT fk_cc3_ticket FOREIGN KEY (cc3) REFERENCES Benutzer(benutzer_id),
    CONSTRAINT fk_ansprechpartner_ticket FOREIGN KEY (ansprechpartner) REFERENCES Benutzer(benutzer_id)
);

CREATE TABLE IF NOT EXISTS Projekte (
    lfdnrPRJ INT PRIMARY KEY,
    PRJ VARCHAR(12),
    PRJ_ZEIT VARCHAR(4),
    KUNDE INT,
    Projektleiter INT,
    ANGELEGT INT,
    interneBemerkung varchar(250),
    BEGIN DATETIME,
    END DATETIME,
    MONATSPRJ TINYINT,
    KM_ORT DECIMAL(6,1),
    FAHRZEIT DECIMAL(6,2),
    VORORT TINYINT,
    erstellt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    geaendert TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_projektleiter_projekte FOREIGN KEY (Projektleiter) REFERENCES Benutzer(benutzer_id),
    CONSTRAINT fk_angelegt_projekte FOREIGN KEY (ANGELEGT) REFERENCES Benutzer(benutzer_id)
);

CREATE TABLE IF NOT EXISTS Fahrzeuge(
    fahrzeug_id INT PRIMARY KEY,
    KfzKZ VARCHAR(10),
    Modell varchar(15)
);

CREATE TABLE IF NOT EXISTS Stundeneintraege(
    std_id INT PRIMARY KEY AUTO_INCREMENT,
    erp_id INT,
    datum DATE,
    mitarbeiter INT,
    projekt INT,
    ticket_nr INT,
    stundenbuchung INT,
    Zeitvon TIME,
    Zeitbis TIME,
    Zeit DECIMAL(6,2),
    Zeit_OB DECIMAL(6,2),
    Art varchar(8),
    Leistung text,
    interne_bemerkung text,
    vorort boolean,
    kundensichtbarkeit boolean,
    KM DECIMAL(4,0),
    FAHRZEIT DECIMAL(6,2),
    Fahrzeug INT,
    is_in_erp TINYINT(1),
    erstellt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    geaendert TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_mitarbeiter_stunden FOREIGN KEY (mitarbeiter) REFERENCES Benutzer(benutzer_id),
    CONSTRAINT fk_projekt_stunden FOREIGN KEY (projekt) REFERENCES Projekte(lfdnrPRJ),
    CONSTRAINT fk_ticket_stunden FOREIGN KEY (ticket_nr) REFERENCES Tickets(ticket_id),
    CONSTRAINT fk_fahrzeug_stunden FOREIGN KEY (Fahrzeug) REFERENCES Fahrzeuge(fahrzeug_id)
);

CREATE TABLE IF NOT EXISTS Kunden(
    kunden_id INT PRIMARY KEY,
    erp_lfdnr INT,
    kunde_name text,
    kunde_kuerzel varchar(8),
    kundenbetreuer INT,
    erstellt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    geaendert TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_kunden_betreuer FOREIGN KEY (kundenbetreuer) REFERENCES Benutzer(benutzer_id)
);

ALTER TABLE Benutzer ADD CONSTRAINT fk_kunde_benutzer FOREIGN KEY (kunde) REFERENCES Kunden(kunden_id);

INSERT INTO Kunden (kunden_id, erp_lfdnr, kunde_name, kunde_kuerzel, kundenbetreuer) VALUES (1, NULL, 'it.liepert.gmbh', '', NULL);
INSERT INTO Benutzer (benutzer_id, ersteller, vorname, nachname, email, passwort, kuerzel, rolle, letzte_aktion, kunde, is_in_erp, aktiv) 
VALUES (100, NULL, 'Connector', '', 'connector@liepert.de', '$argon2id$v=19$m=65536,t=3,p=1$w3qWJxjiypfkLLmoLZz+Fw$orBWaO8UGpNVnUvAvaks2KQJtvqsT+6ouhw1e99E3Ew', 'CNCT', 'connector', NULL, 1, 1, 1);
INSERT INTO Benutzer (benutzer_id, ersteller, vorname, nachname, email, passwort, kuerzel, rolle, letzte_aktion, kunde, is_in_erp, aktiv) 
VALUES (101, NULL, 'Pool', '', 'pool@liepert.de', '', 'POOL', 'pool', NULL, 1, 1, 1);