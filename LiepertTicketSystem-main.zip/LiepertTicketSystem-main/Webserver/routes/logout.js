import express from 'express';
const router = express.Router();
import { createClient } from 'redis';
import writeLog from '../modules/utils/writeLog.js';

const redisClient = createClient({
    url: 'redis://localhost:6379'
});

(async () =>{
    try{
        await redisClient.connect();
    } catch(err){
        writeLog('login: Redis Verbindungsfehler: ' + err);
        await redisClient.quit().catch(() => {});
    }
})();

router.post('/', async (req, res) => {
    const token = req.cookies.session_token;
    if(token){
        await redisClient.del(`sess:${token}`).catch(() => {});
    }
    res.clearCookie('session_token');
    res.status(200).json({ message: "Logout erfolgreich" });
});

export default router;