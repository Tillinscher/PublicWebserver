import express from 'express';
import { createClient } from 'redis';
import writeLog from '../modules/utils/writeLog.js';

const router = express.Router();

const redisClient = createClient({
    url: 'redis://localhost:6379'
});

(async () =>{
    try{
        await redisClient.connect();
    } catch(err){
        writeLog('login: Redis Verbindungsfehler: ' + err);
        await redisClient.quit().catch(() => {});
    }
})();

router.get('/', async (req, res) => {
    const token = req.cookies.session_token;
    if (!token) return res.redirect('/login');
    const sessionKey = `sess:${token}`;
    let sessionData;
    try{
        const redisData = await redisClient.get(sessionKey);
        if(redisData){
            sessionData = JSON.parse(redisData);
        }
    }catch(error){
        writeLog('me: Redis Fehler: ' + error);
        console.log(error);
    }
    res.status(200).json({
        benutzer_id: sessionData.benutzer_id,
        nachname: sessionData.nachname,
        vorname: sessionData.vorname,
        email: sessionData.email,
        kunde: sessionData.kunde,
        kunde_name: sessionData.kunde_name,
        rolle: sessionData.rolle
    });
});

export default router;