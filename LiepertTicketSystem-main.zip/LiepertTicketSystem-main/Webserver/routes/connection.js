import express from 'express'
const router = express.Router();

import {getStatistiken} from '../modules/connector/statistiken.js';
import { updateFahrzeuge, sendeFahrzeugeAnERP } from '../modules/connector/fahrzeuge.js';
import { updateTickets, sendeTicketsAnERP } from '../modules/connector/tickets.js';
import { updateStundeneintraege, sendeStundeneintrag } from '../modules/connector/stundeneintrag.js';
import { updateKunden, sendeKundenAnERP } from '../modules/connector/kunden.js';
import { updateProjekte, sendeProjekteAnERP } from '../modules/connector/projekte.js';

router.get('/', getStatistiken);

router.post('/fahrzeuge', updateFahrzeuge);
router.get('/fahrzeuge', sendeFahrzeugeAnERP);

router.post('/kunden', updateKunden);
router.get('/kunden', sendeKundenAnERP);

router.post('/stundeneintraege', updateStundeneintraege);
router.get('/stundeneintraege', sendeStundeneintrag);

router.post('/tickets', updateTickets);
router.get('/tickets', sendeTicketsAnERP);

router.post('/projekte', updateProjekte);
router.get('/projekte', sendeProjekteAnERP);

export default router;