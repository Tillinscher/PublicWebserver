import express from 'express';
const router = express.Router();

import { ticketAuthorization, benutzerKontrolle } from '../modules/utils/requireAuth.js';

import { tickets, ticketanzahl } from '../modules/get/tickets.js';
import createTicket from '../modules/post/createTicket.js';
import benutzer from '../modules/get/benutzer.js';
import setBenutzer from '../modules/post/benutzer.js';
import updateBenutzer from '../modules/update/benutzer.js';
import kunden from '../modules/get/kunden.js';
import fahrzeuge from '../modules/get/fahrzeuge.js';
import stundeneintraege from '../modules/get/stundeneintraege.js';
import erstelleStundeneintrag from '../modules/post/stundeneintrag.js';
import updateStundeneintrag from '../modules/update/stundeneintrag.js';
import updateTicketField from '../modules/update/ticket.js';
import getProjekte from '../modules/get/projekte.js';

router.get('/tickets', ticketAuthorization, tickets);
router.post('/tickets', createTicket);
router.put('/tickets', ticketAuthorization, updateTicketField);
router.get('/ticketanzahl', ticketanzahl);

router.get('/benutzer', benutzerKontrolle, benutzer);
router.post('/benutzer', setBenutzer);
router.put('/benutzer', benutzerKontrolle, updateBenutzer);

router.get('/kunden', kunden);
router.get('/fahrzeuge', fahrzeuge);

router.get('/stundeneintrag', ticketAuthorization, stundeneintraege);
router.post('/stundeneintrag', ticketAuthorization, erstelleStundeneintrag);
router.put('/stundeneintrag', ticketAuthorization, updateStundeneintrag);

router.get('/projekte', ticketAuthorization, getProjekte);

export default router;