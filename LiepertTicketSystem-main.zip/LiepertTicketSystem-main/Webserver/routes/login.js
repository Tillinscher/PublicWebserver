import express from 'express';
import path from 'path';
import { createClient } from 'redis';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import writeLog from '../modules/utils/writeLog.js';
import { fallbackSessions, SESSION_TTL } from '../modules/utils/sessionStore.js';
import pool from '../modules/utils/dbconfig.js'
import { verifyPassword } from '../modules/utils/passwortHash.js';

const router = express.Router();
const redisClient = createClient({
    url: 'redis://localhost:6379'
});

(async () =>{
    try{
        await redisClient.connect();
    } catch(err){
        writeLog('login: Redis Verbindungsfehler: ' + err);
        await redisClient.quit().catch(() => {});
    }
})();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

router.get('/', (req, res) => {
    res.render("login");
});

router.post('/', async (req, res) => {
    const { email, password } = req.body;

    try {
        // Mit await und mysql2/promise
        const [results] = await pool.query('SELECT * FROM Benutzer WHERE email = ?', [email]);

        if (!results || results.length === 0) {
            return res.status(401).json({ message: 'Ungültige Anmeldedaten' });
        }

        const benutzer = results[0];

        let pwdkorrekt = false;
        try {
            pwdkorrekt = await verifyPassword(benutzer.passwort, password);
        } catch (err) {
            return res.status(500).send({ details: 'Fehler bei Passwortprüfung' });
        }

        if (!pwdkorrekt) {
            return res.status(401).json({ message: 'Ungültige Anmeldedaten' });
        }

        const sessionToken = crypto.randomBytes(32).toString("hex");
        const sessionData = JSON.stringify(benutzer);

        try {
            await redisClient.setEx(`sess:${sessionToken}`, SESSION_TTL, sessionData);
        } catch (error) {
            console.error('Redis Fehler:', error);
            return res.status(500).send({ details: "Redis Client Fehler " + error });
        }
        console.log(benutzer.benutzer_id);

        if(benutzer.benutzer_id === 100){
            console.log('Login erfolgreich für Connector:', benutzer.email);
            return res.status(200).send({ key: sessionToken});
        }

        res.cookie('session_token', sessionToken, { 
            httpOnly: true,
            sameSite: 'Strict',
            maxAge: SESSION_TTL * 1000
        });

        console.log('Login erfolgreich für:', email);
        return res.redirect('/');

    } catch (error) {
        console.error('Datenbankfehler:', error);
        return res.status(500).send({ details: 'Datenbank Fehler' });
    }
});


export default router;