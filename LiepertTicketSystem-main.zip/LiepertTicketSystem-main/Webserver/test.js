import { sendeEmailBenachrichtigung } from './modules/post/createTicket.js';
import sendEmail from './modules/utils/email.js';

//sendEmail("luca.tillinger@liepert.de", "Test", "Test");

// Beispielaufruf der Funktion zum Senden einer E-Mail-Benachrichtigung
sendeEmailBenachrichtigung(1, 'Beschreibung des Tickets', 1, 41)