import pool from '../utils/dbconfig.js';
import writeConnector from '../utils/logSynch.js';

async function updateFahrzeuge(req, res) {
    const { fahrzeuge } = req.body;
    if (!Array.isArray(fahrzeuge)) {
        return res.status(400).json({ error: 'Ungültiges Datenformat' });
    }
    
    fahrzeuge.forEach(async (fahrzeug) => {
        const { lfdnr, KfzKZ, Modell, neuerEintrag } = fahrzeug;
        let sql;
        let params = [];
        if (neuerEintrag) {
            sql = `
                INSERT INTO fahrzeuge (fahrzeug_id, KfzKZ, Modell)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE KfzKZ = ?, Modell = ?
            `;
            params = [lfdnr, KfzKZ, Modell, KfzKZ, Modell];
        } else {
            sql = `DELETE FROM fahrzeuge WHERE fahrzeug_id = ?;`
            params = [lfdnr];
        }
        try {
            await pool.execute(sql, [lfdnr, KfzKZ, Modell]);
        } catch (error) {
            writeConnector('Fehler beim Aktualisieren der Fahrzeuge: ' + error);
        }
    });

    res.status(200).json({ message: 'Fahrzeuge wurden aktualisiert.' });
    writeConnector('Fahrzeuge ' + fahrzeuge + ' wurden erfolgreich aktualisiert.');
}

async function sendeFahrzeugeAnERP(req, res) {
    let ids = [];
    const sql = "SELECT fahrzeug_id, geandert FROM fahrzeuge";
    pool.execute(sql)
    .then(([rows]) => {
        ids = rows;
    })
    .catch (error => {
        writeConnector('Fehler beim Senden der Fahrzeuge an das ERP-System: ' + error);
        res.status(500).json({ error: 'Interner Serverfehler' });
    });
    // Nur ids zum Abgleich nötig, da Fahrzeuge im Webserver nicht geändert werden können
    res.status(200).json({ fahrzeug_ids: ids });
}

export { updateFahrzeuge, sendeFahrzeugeAnERP };