import pool from '../utils/dbconfig.js';
import writeConnector from '../utils/logSynch.js';

async function updateKunden(req, res) {
    const { kunden } = req.body;
    if (!Array.isArray(kunden)) {
        return res.status(400).json({ error: 'Ungültiges Datenformat' });
    }
    kunden.forEach(async (kunde) => {
        const { lfdnr, LIE_N1, LIE_KD, Betreuer, angelegt } = kunde;
        let sql;
        let params = [];
        if (neuerEintrag) {
            sql = `
                INSERT INTO kunden (kunden_id, kunden_name, kunde_kuerzel, kundenbetreuer, erstellt)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE kunden_name = ?, kunde_kuerzel = ?, kundenbetreuer = ?
            `;
            params = [lfdnr, LIE_N1, LIE_KD, Betreuer, angelegt, LIE_N1, LIE_KD, Betreuer];
        } else {
            sql = `DELETE FROM kunden WHERE kunden_id = ?;`
            params = [lfdnr];
        }
        try {
            await pool.execute(sql, params);
        } catch (error) {
            writeConnector('Fehler beim Aktualisieren der Kunden: ' + error);
            res.status(500).json({ error: 'Interner Serverfehler' });
            return;
        }
    });

    res.status(200).json({ message: 'Kunden wurden aktualisiert.' });
    writeConnector('Kunden ' + kunden + ' wurden erfolgreich aktualisiert.');
}

async function sendeKundenAnERP(req, res) {
    let ids = [];
    const sql = "SELECT kunden_id, geandert FROM kunden";
    pool.execute(sql)
    .then(([rows]) => {
        ids = rows;
    })
    .catch (error => {
        writeConnector('Fehler beim Senden der Kunden an das ERP-System: '+ error);
        res.status(500).json({ error: 'Interner Serverfehler' });
    });
    // Nur ids zum Abgleich nötig, da Kunden im Webserver nicht geändert werden können
    res.status(200).json({ kunden_ids: ids });
}

export { updateKunden, sendeKundenAnERP };