import pool from '../utils/dbconfig.js';
import writeConnector from '../utils/logSynch.js';

async function updateProjekte(req, res) {
    const { projekte } = req.body;
    if (!Array.isArray(projekte)) {
        return res.status(400).json({ error: 'Ungültiges Datenformat' });
    }
    
    projekte.forEach(async (projekt) => {
        const { lfdnrPRJ, PRJ, PRJ_ZEIT, KUNDE, Projektleiter, ANGELEGT, interneBemerkung, BEGIN, END, MONATSPRJ, KM_ORT, FAHRZEIT, VORORT, neuerEintrag } = projekt;
        let sql;
        let params = [];
        if (neuerEintrag) {
            sql = `
                INSERT INTO projekte (lfdnrPRJ, PRJ, PRJ_ZEIT, KUNDE, Projektleiter, ANGELEGT, interneBemerkung, BEGIN, END, MONATSPRJ, KM_ORT, FAHRZEIT, VORORT)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE PRJ = ?, PRJ_ZEIT = ?, KUNDE = ?, Projektleiter = ?, ANGELEGT = ?, interneBemerkung = ?, BEGIN = ?, END = ?, MONATSPRJ = ?, KM_ORT = ?, FAHRZEIT = ?, VORORT = ?
            `;
            params = [
                // INSERT Parameter
                lfdnrPRJ, PRJ, PRJ_ZEIT, KUNDE, Projektleiter, ANGELEGT, interneBemerkung, BEGIN, END, MONATSPRJ, KM_ORT, FAHRZEIT, VORORT,
            
                // UPDATE Parameter
                PRJ, PRJ_ZEIT, KUNDE, Projektleiter, ANGELEGT, interneBemerkung, BEGIN, END, MONATSPRJ, KM_ORT, FAHRZEIT, VORORT
            ];
        } else {
            sql = `DELETE FROM projekte WHERE lfdnrPRJ = ?;`
            params = [lfdnrPRJ];
        }
        try {
            await pool.execute(sql, params);
        } catch (error) {
            writeConnector('Fehler beim Aktualisieren der Projekte: ' + error);
        }
    });

    res.status(200).json({ message: 'Projekte wurden aktualisiert.' });
    writeConnector('Projekte ' + projekte + ' wurden erfolgreich aktualisiert.');
}

async function sendeProjekteAnERP(req, res) {
    let ids = [];
    const sql = "SELECT lfdnrPRJ, geandert FROM projekte";
    pool.execute(sql)
    .then(([rows]) => {
        ids = rows;
    })
    .catch (error => {
        writeConnector('Fehler beim Senden der Projekte an das ERP-System: '+ error);
        res.status(500).json({ error: 'Interner Serverfehler' });
    });
    // Nur ids zum Abgleich nötig, da Projekte im Webserver nicht geändert werden können
    res.status(200).json({ projekt_ids: ids });
}

export { updateProjekte, sendeProjekteAnERP };