import pool from '../utils/dbconfig.js';
import writeConnector from '../utils/logSynch.js';

async function updateStundeneintraege(req, res) {
    const { stundeneintraege } = req.body;
    if (!Array.isArray(stundeneintraege)) {
        return res.status(400).json({ error: 'Ungültiges Datenformat' });
    }
    
    stundeneintraege.forEach(async (eintrag) => {
        const { lfdNr, DATUM, Mitarbeiter, PRJ, TicketNr, StundenBuchung, Zeitvon, Zeitbis, ZEIT, ZEIT_OB, Art, Leistung, interneBemerkung, VORORT, KM, FAHRZEIT, FAHRZEUG, Zeitstempel, neuerEintrag} = eintrag;
        let sql;
        let params = [];
        if (neuerEintrag) {
            sql = `
                INSERT INTO stundeneintraege (erp_id, datum, mitarbeiter, projekt, ticket_nr, stundenbuchung, Zeitvon, Zeitbis, Zeit, Zeit_OB, Art, Leistung, interne_bemerkung, vorort, KM, FAHRZEIT, Fahrzeug, erstellt, is_in_erp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                ON DUPLICATE KEY UPDATE datum = ?, mitarbeiter = ?, projekt = ?, ticket_nr = ?, stundenbuchung = ?, Zeitvon = ?, Zeitbis = ?, Zeit = ?, Zeit_OB = ?, Art = ?, Leistung = ?, interne_bemerkung = ?, vorort = ?, KM = ?, FAHRZEIT = ?, Fahrzeug = ?, erstellt = ?, is_in_erp = 1
            `;
            params = [
                // INSERT Parameter
                lfdNr, DATUM, Mitarbeiter, PRJ, TicketNr, StundenBuchung, Zeitvon, Zeitbis, ZEIT, ZEIT_OB, Art, Leistung, interneBemerkung, VORORT, KM, FAHRZEIT, FAHRZEUG, Zeitstempel,
                
                // UPDATE Parameter
                DATUM, Mitarbeiter, PRJ, TicketNr, StundenBuchung, Zeitvon, Zeitbis, ZEIT, ZEIT_OB, Art, Leistung, interneBemerkung, VORORT, KM, FAHRZEIT, FAHRZEUG, Zeitstempel
            ];
        } else {
            sql = `DELETE FROM stundeneintraege WHERE erp_id = ?;`
            params = [lfdNr];
        }
        try {
            await pool.execute(sql, params);
        } catch (error) {
            writeConnector('Fehler beim Aktualisieren der Stundeneinträge: ' + error);
            res.status(500).json({ error: 'Interner Serverfehler' });
            return;
        }
    });

    res.status(200).json({ message: 'Stundeneinträge wurden aktualisiert.' });
    writeConnector('Stundeneinträge ' + stundeneintraege + ' wurden erfolgreich aktualisiert.');
}

async function sendeStundeneintrag(req, res){
    let ids = [];
    const sql = "SELECT stundeneintrag_id, geandert FROM stundeneintraege";
    pool.execute(sql)
    .then(([rows]) => {
        ids = rows;
    })
    .catch (error => {
        writeConnector('Fehler beim Senden der Stundeneinträge an das ERP-System: ' + error);
        res.status(500).json({ error: 'Interner Serverfehler' });
        return;
    });

    const aenderungenQuery = "SELECT * FROM stundeneintraege WHERE is_in_erp = 0";
    pool.execute(aenderungenQuery)
    .then(([rows]) => {
        res.status(200).json({ stundeneintrag_ids: ids, stundeneintrag_aenderungen: rows });
    })
    .catch (error => {
        writeConnector('Fehler beim Senden der Stundeneinträge an das ERP-System: ' + error);
        res.status(500).json({ error: 'Interner Serverfehler' });
        return;
    });

    // Markiere die Einträge als in ERP gesendet
    const updateQuery = "UPDATE stundeneintraege SET is_in_erp = 1 WHERE is_in_erp = 0";
    pool.execute(updateQuery);
}

export { updateStundeneintraege, sendeStundeneintrag };