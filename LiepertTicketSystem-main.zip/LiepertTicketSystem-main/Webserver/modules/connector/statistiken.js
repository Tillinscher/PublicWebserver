import pool from '../utils/dbconfig.js';
import writeConnector from '../utils/logSynch.js';

/**
 * Gibt zurück, wie viele Einträge in den verschiedenen Tabellen noch nicht ins ERP-System übertragen wurden.
 * @param {*} req 
 * @param {*} res 
 */
async function getStatistiken(req, res) {
    try {
        const [ticketRows] = await pool.execute('SELECT COUNT(*) AS ticketCount FROM tickets WHERE is_in_erp = 0;');
        const [stundeneintraegeRows] = await pool.execute('SELECT COUNT(*) AS stundeneintraegeCount FROM stundeneintraege WHERE erp_id = NULL;');
        const statistiken = {
            tickets: ticketRows[0].ticketCount,
            stundeneintraege: stundeneintraegeRows[0].stundeneintraegeCount
        };
        res.status(200).json(statistiken);
    }
    catch (error) {
        writeConnector('Fehler beim Abrufen der Statistiken: ' + error);
        res.status(500).json({ error: 'Interner Serverfehler' });
    }
}

export { getStatistiken };