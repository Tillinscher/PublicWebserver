import pool from '../utils/dbconfig.js';
import writeConnector from '../utils/logSynch.js';

async function updateTickets(req, res) {
    const { erp_nummern, ticketUpdates } = req.body;
    if (!Array.isArray(erp_nummern) || !Array.isArray(ticketUpdates)) {
        return res.status(400).json({ error: 'Ungültiges Datenformat' });
    }

    for (const ticket of ticketUpdates) {
        const { TicketNr, vom, Zeitstempel, von, Kunde, Meldung, Termin, an, cc, cc2, cc3, Status, gelesen, erledigt, itAngebotsNr, Ansprechpartner } = ticket;
        let sql;
        let params = [];
        if (neuerEintrag) {
            sql = `
                INSERT INTO tickets (erp_ticketnr, erstellt, geaendert, ersteller, kunde, beschreibung, termin, bearbeiter, cc, cc2, cc3, status, gelesen, erledigt, angebot, ansprechpartner, is_in_erp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                ON DUPLICATE KEY UPDATE erp_ticketnr = ?, erstellt = ?, geaendert = ?, ersteller = ?, kunde = ?, beschreibung = ?, termin = ?, bearbeiter = ?, cc = ?, cc2 = ?, cc3 = ?, status = ?, gelesen = ?, erledigt = ?, angebot = ?, ansprechpartner = ?
            `;
            params = [ TicketNr, vom, Zeitstempel, von, Kunde, Meldung, Termin, an, cc, cc2, cc3, Status, gelesen, erledigt, itAngebotsNr, Ansprechpartner,
                       TicketNr, vom, Zeitstempel, von, Kunde, Meldung, Termin, an, cc, cc2, cc3, Status, gelesen, erledigt, itAngebotsNr, Ansprechpartner ];
        } else {
            sql = `DELETE FROM tickets WHERE ticket_id = ?;`
            params = [lfdnr];
        }
        try {
            await pool.execute(sql, params);
            writeConnector('Ticket ' + lfdnr + ' wurde erfolgreich aktualisiert.');
        } catch (error) {
            res.status(500).json({ error: 'Interner Serverfehler, Tickets wurden nicht oder nur teilweise aktualisiert' });
            writeConnector('Fehler beim Aktualisieren der Tickets: ' + error);
            return;
        }
    }

    for (const erp_nummer of erp_nummern) {
        const sql = `
            UPDATE tickets
            SET is_in_erp = 1, erp_ticketnr = ?
            WHERE ticket_id = ?;
        `;
        const params = [erp_nummer.ticket_id, erp_nummer.erp_ticketnr];
        try {
            await pool.execute(sql, params);
            writeConnector('ERP Nummer für Ticket ' + erp_nummer.ticket_id + ' wurde erfolgreich aktualisiert.');
        } catch (error) {
            res.status(500).json({ error: 'Interner Serverfehler, Tickets wurden aktualisiert, ERP Nummer NICHT' });
            writeConnector('Fehler beim Aktualisieren der ERP Nummern: ' + error);
            return;
        }
    }
}

async function sendeTicketsAnERP(req, res){
    let ids = [];
    let aenderungen = [];
    const sql = "SELECT ticket_id, geandert FROM tickets";
    pool.execute(sql)
    .then(([rows]) => {
        ids = rows;
        //return res.status(200).json({ ticket_ids: ids });
    })
    .catch (error => {
        writeConnector('Fehler beim Senden der Tickets an das ERP-System: '+ error);
        return res.status(500).json({ error: 'Interner Serverfehler' });
    });
    const ticketAenderungenQuery = "SELECT * FROM tickets WHERE is_in_erp = 0";
    pool.execute(ticketAenderungenQuery)
    .then(([rows]) => {
        res.status(200).json({ ticket_ids: ids, ticket_aenderungen: rows });
    })
    .catch (error => {
        writeConnector('Fehler beim Abrufen der Ticketänderungen: ', error);
        return res.status(500).json({ error: 'Interner Serverfehler' });
    });
    // Markiere die Einträge als in ERP gesendet
    const updateQuery = "UPDATE tickets SET is_in_erp = 1 WHERE is_in_erp = 0";
    pool.execute(updateQuery);
}

export { updateTickets, sendeTicketsAnERP };