import pool from '../utils/dbconfig.js';
import writeLog from '../utils/writeLog.js';

async function stundeneintrag(req, res) {
    const { id, field, value } = req.body;

    const allowedFields = [
        "Zeitvon",
        "Zeitbis",
        "datum",
        "mitarbeiter",
        "Leistung",
        "interne_bemerkung",
        "stundenbuchung",
        "projekt",
        "art",
        "zeit",
        "Zeit_OB",
        "vorort",
        "KM",
        "fahrzeit",
        "Fahrzeug",
        "kundensichtbarkeit"
    ];

    if (!allowedFields.includes(field)) {
        return res.status(400).json({ details: 'Ungültiges Feld' });
    }

    try {
        const updateSql = `UPDATE stundeneintraege SET ${field} = ? WHERE std_id = ?`;
        await pool.query(updateSql, [value, id]);

        if (field === 'Zeitvon' || field === 'Zeitbis') {
            const fetchSql = `SELECT Zeitvon, Zeitbis FROM stundeneintraege WHERE std_id = ?`;
            const [rows] = await pool.query(fetchSql, [id]);

            if (rows.length === 0) {
                return res.status(404).json({ details: 'Stundeneintrag nicht gefunden' });
            }

            const { Zeitvon, Zeitbis } = rows[0];

            if (Zeitvon && Zeitbis) {
                const [sh, sm] = Zeitvon.split(':').map(Number);
                const [eh, em] = Zeitbis.split(':').map(Number);

                let totalMinutes = (eh * 60 + em) - (sh * 60 + sm);
                if (totalMinutes < 0) totalMinutes += 24 * 60;

                const calculatedZeit = Number((totalMinutes / 60).toFixed(2));

                const updateZeitSql = `UPDATE stundeneintraege SET Zeit = ? WHERE std_id = ?`;
                await pool.query(updateZeitSql, [calculatedZeit, id]);

                return res.status(200).json({
                    details: 'Stundeneintrag und Zeit aktualisiert',
                    zeit: calculatedZeit
                });
            }

            
        }
        if(field === "vorort" && value === false){
            await pool.query("UPDATE stundeneintraege SET KM = null, fahrzeit = null WHERE std_id = ?", [id]);
        }

        return res.status(200).json({ details: 'Stundeneintrag updated successfully' });

    } catch (error) {
        writeLog('Unexpected error updating stundeneintrag: ' + error.message);
        return res.status(500).json({
            details: 'Unerwarteter Fehler bei Aktualisierung eines Stundeneintrags'
        });
    }
}

export default stundeneintrag;