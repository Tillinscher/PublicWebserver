import pool from '../utils/dbconfig.js';
import writeLog from '../utils/writeLog.js';
import { hashPassword } from '../utils/passwortHash.js';

async function deleteAllUserSessions(userId) {
    try {
        // SCAN statt KEYS, um große Mengen effizient zu durchsuchen
        let cursor = 0;
        let deletedCount = 0;

        do {
            const [nextCursor, keys] = await redisClient.scan(cursor, 'MATCH', 'sess:*', 'COUNT', 100);
            cursor = Number(nextCursor);

            if (keys.length > 0) {
                // Alle Sessions laden
                const sessions = await Promise.all(keys.map(key => redisClient.get(key)));

                for (let i = 0; i < sessions.length; i++) {
                    const sessionData = sessions[i];
                    if (!sessionData) continue;

                    const sessionObj = JSON.parse(sessionData);
                    if (sessionObj.id === userId) { // oder sessionObj.email === email
                        await redisClient.del(keys[i]);
                        deletedCount++;
                    }
                }
            }
        } while (cursor !== 0);

        console.log(`Gelöschte Sessions für Benutzer ${userId}: ${deletedCount}`);
        return deletedCount;
    } catch (err) {
        console.error('Fehler beim Löschen der Benutzer-Sessions:', err);
        return 0;
    }
}


async function benutzer(req, res) {
    const { benutzer_id, vorname, nachname, email, rolle, passwort, aktiv } = req.query;

    let fields = [];
    let params = [];

    if (aktiv !== undefined) {
        fields.push("aktiv = ?");
        params.push(parseInt(aktiv, 10));
    } else {
        fields.push("vorname = ?", "nachname = ?", "email = ?", "rolle = ?");
        params.push(vorname, nachname, email, rolle);

        if (passwort) {
            fields.push("passwort = ?");
            params.push(await hashPassword(passwort));
        }
    }

    params.push(parseInt(benutzer_id, 10));

    const sql = `
        UPDATE benutzer
        SET ${fields.join(", ")}
        WHERE benutzer_id = ?
    `;

    try{
        const [result] = await pool.query(sql, params);
        return res.status(200).send();
    } catch(err){
        writeLog("Fehler beim Update des Benutzers: " + err);
        return res.status(500).send("Interner Serverfehler");
    }

}

export default benutzer;