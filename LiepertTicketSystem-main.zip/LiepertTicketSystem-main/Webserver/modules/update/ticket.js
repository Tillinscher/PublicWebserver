import pool from '../utils/dbconfig.js';
import writeLog from '../utils/writeLog.js';

async function updateTicketField(req, res) {
    const { ticketId, field, value } = req.body;

    const allowedFields = ['beschreibung', 'kunde', 'bearbeiter', 'cc', 'cc2', 'cc3', 'status', 'termin', 'ansprechpartner'];
    if (!allowedFields.includes(field)) {
        res.status(400).json({ error: 'Ungültiges Feld' });
        return;
    }
    console.log(`Aktualisiere Ticket ${ticketId}: Setze ${field} auf ${value}`);
    try {
        const query = `UPDATE tickets SET ${field} = ? WHERE ticket_id = ?`;
        await pool.execute(query, [value, ticketId]);
        res.json({ success: true });
    } catch (error) {
        writeLog('Fehler beim Aktualisieren des Tickets: ' + error);
        res.status(500).json({ error: 'Interner Serverfehler' });
    }
}

export default updateTicketField;