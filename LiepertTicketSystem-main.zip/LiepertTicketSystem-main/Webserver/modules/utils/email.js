import nodemailer from 'nodemailer';
import writelog from './writeLog.js';

/**
 * Sendet eine E-Mail von ticket@liepert.de mit den angegegbenen Parametern
 * @param {string} empfaenger - Empfänger der E-Mail
 * @param {string} betreff - Betreff der E-Mail
 * @param {string} [text] - Plaintextinhalt der E-Mail
 * @param {string} [html] - (Optional) HTML-Inhalt der E-Mail für bessere Formatierung
 */
async function sendEmail(empfaenger, betreff, text, html) {
    const transporter = nodemailer.createTransport({
        host: "smtp.strato.de",
        port: 465,
        secure: true,
        auth: {
            user: "ticket@liepert.de",
            pass: "d!6-XZmu_yac",
        },
    });

    const mailoptionen = {
        from: "ticket@liepert.de",
        to: empfaenger,
        subject: betreff,
        text: text,
        if(html) {
            this.html = html;
        }
    };

    try{
        const info = await transporter.sendMail(mailoptionen);
    } catch (error) {
        writelog("Fehler beim E-Mail Versand an: " + empfaenger + ": ", error);
    }
}

export default sendEmail;