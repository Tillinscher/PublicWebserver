import argon2 from 'argon2';
import { hash } from 'crypto';

const ARGON2_OPTIONS = {
    type: argon2.argon2id,
    memoryCost: 1 << 16,
    timeCost: 3,
    parallelism: 1,
    hashLength: 32,
};

async function hashPassword(password) {
    if(typeof password !== 'string' || password.length === 0) {
        throw new Error('Das Passwort muss ein nichtleerer String sein');
    }
    const pepper = process.env.PEPPER || '';
    const pwdMitPepper = password + pepper;

    return argon2.hash(pwdMitPepper, ARGON2_OPTIONS);
}

async function verifyPassword(hash, passwort){
    if(typeof passwort !== 'string' || passwort.length === 0) {
        return false;
    }
    if(typeof hash !== 'string' || hash.length === 0) {
        return false;
    }
    const pepper = process.env.PEPPER || '';
    const pwdMitPepper = passwort + pepper;
    try{
        return await argon2.verify(hash, pwdMitPepper);
    }catch(err){
        return false;
    }
}

export { hashPassword, verifyPassword };