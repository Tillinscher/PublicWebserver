import { createClient } from 'redis';

function redisCheck(){
    const redisClient = createClient({
        url: 'redis://localhost:6379'
    });

    (async () =>{
        try{
            await redisClient.connect();
        } catch(err){
            writeLog('login: Redis Verbindungsfehler: ' + err);
            await redisClient.quit().catch(() => {});
        }
    })();
}

export default redisCheck;