const serverAdresse = "https://localhost:3030";

export {serverAdresse};