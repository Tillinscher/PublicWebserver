import { createClient } from 'redis';
import writeLog from './writeLog.js';
import { fallbackSessions, SESSION_TTL } from './sessionStore.js';
import pool from './dbconfig.js';

const redisClient = createClient({
    url: 'redis://localhost:6379'
});

(async () =>{
    try{
        await redisClient.connect();
    } catch(err){
        writeLog('requireAuth: Redis Verbindungsfehler: ' + err);
        await redisClient.quit().catch(() => {});
    }
})();

/**
 * Prüft, ob eine Session existiert und verlängert diese
 * bei Bedarf. Leitet ansonsten auf die Login-Seite weiter.
 * @middleware
*/
async function requireAuth(req, res, next) {
    const token = req.cookies.session_token;
    if (!token) return res.redirect('/login');
  
    const sessionKey = `sess:${token}`;
    let sessionData;

    try{
        const redisData = await redisClient.get(sessionKey);
        if(redisData){
            sessionData = JSON.parse(redisData);
            await redisClient.expire(sessionKey, SESSION_TTL);
        } 
    }catch(error){
        writeLog('requireAuth: Redis Fehler: ' + error);
    }

    if(!sessionData && fallbackSessions.has(token)){
        const entry = fallbackSessions.get(token);
        if(Date.now() < entry.expiresAt){
            sessionData = entry.data;
            entry.expiresAt = Date.now() + (SESSION_TTL * 1000);
        } else {
            fallbackSessions.delete(token);
        }
    }
  
    if (!sessionData)
        return res.redirect('/login');
  
    await redisClient.expire(sessionKey, SESSION_TTL);
    pool.query("UPDATE BENUTZER SET letzte_aktion = NOW() WHERE benutzer_id = ?", [sessionData.benutzer_id])
    .catch((error) => {
        writeLog("Fehler beim aktualisieren der Benutzeranmeldung: " + error);
        console.log(error);
    });
    req.user = sessionData;
    next();
}

async function benutzerKontrolle(req, res, next) {
    const token = req.cookies.session_token;
    if (!token) return res.redirect('/login');
    const sessionKey = `sess:${token}`;
    let sessionData;

    try{
        const redisData = await redisClient.get(sessionKey);
        if(redisData){
            sessionData = JSON.parse(redisData);
            if(sessionData.kunde === 1) next();
            if(req.query.benutzer_id === sessionData.benutzer_id) next();
            const [response] = await pool.query("SELECT * FROM benutzer WHERE benutzer_id=" + req.query.benutzer_id);
            if(response[0].kunde === sessionData.kunde && sessionData.rolle === "Firmenadministrator") next();
            res.status(403).send("Zugriff verweigert");
            await redisClient.expire(sessionKey, SESSION_TTL);
        } 
    }catch(error){
        writeLog('requireAuth: Redis Fehler: ' + error);
    }
}

async function requireConnector(req, res, next) {
    const token = req.body.session_token;
    if (!token) return res.redirect('/login');
    const sessionKey = `sess:${token}`;
    let sessionData;

    try{
        const redisData = await redisClient.get(sessionKey);
        if(redisData){
            sessionData = JSON.parse(redisData);
            if(sessionData.benutzer_id !== '100'){
                return res.status(403).send('Zugriff verweigert: Nur für Connectoren');
            }
            writeLog('Abgefragte Daten des Connectors: ' + JSON.stringify(req.body));
            await redisClient.expire(sessionKey, SESSION_TTL);
            next();
        }
        else {
            return res.status(403).send('Zugriff verweigert: Ungültiges Session Token');
        }
    }catch(error){
        writeLog('requireAuth: Redis Fehler: ' + error);
    }
}

async function requireKunde(req, res, next) {
    const token = req.cookies.session_token;
    if (!token) return res.redirect('/login');
    const sessionKey = `sess:${token}`;
    let sessionData;

    try{
        const redisData = await redisClient.get(sessionKey);
        if(redisData){
            sessionData = JSON.parse(redisData);
            await redisClient.expire(sessionKey, SESSION_TTL);
        } 
    }catch(error){
        writeLog('requireAuth: Redis Fehler: ' + error);
    }
}

async function requireSystemAdmin(req, res, next) {
    const token = req.cookies.session_token;
    if (!token) return res.redirect('/login');
    const sessionKey = `sess:${token}`;
    let sessionData;

    try{
        const redisData = await redisClient.get(sessionKey);
        if(redisData){
            sessionData = JSON.parse(redisData);
            if(sessionData.rolle !== 'Systemadministrator'){
                return res.status(403).send('Zugriff verweigert: Nur für Systemadministratoren');
            }
            await redisClient.expire(sessionKey, SESSION_TTL);
            next();
        } 
    }catch(error){
        writeLog('requireAuth: Redis Fehler: ' + error);
    }
}

async function requireFirmenadmin(req, res, next) {
    const token = req.cookies.session_token;
    if (!token) return res.redirect('/login');
    const sessionKey = `sess:${token}`;
    let sessionData;

    try{
        const redisData = await redisClient.get(sessionKey);
        if(redisData){
            sessionData = JSON.parse(redisData);
            if(sessionData.rolle !== 'Firmenadministrator'){
                return res.status(403).send('Zugriff verweigert: Nur für Firmenadministratoren');
            }
            await redisClient.expire(sessionKey, SESSION_TTL);
            next();
        } 
    }catch(error){
        writeLog('requireAuth: Redis Fehler: ' + error);
    }
}

async function ticketAuthorization(req, res, next) {
    const token = req.cookies.session_token;
    if (!token) return res.redirect('/login');
    const sessionKey = `sess:${token}`;
    let sessionData;

    try{
        const redisData = await redisClient.get(sessionKey);
        if(redisData){
            sessionData = JSON.parse(redisData);
            if(sessionData.rolle === 'Systemadministrator' || sessionData.kunde === 1){
                await redisClient.expire(sessionKey, SESSION_TTL);
                return next();
            }
            if(sessionData.rolle === 'Firmenadministrator'){
                const ticketId = req.params.id || req.query.id;
                const [rows] = await pool.query("SELECT * FROM tickets WHERE ticket_id = ?", [ticketId]);
                if(rows.length === 0){
                    return res.status(404).send('Ticket nicht gefunden');
                }
                const ticket = rows[0];
                if(ticket.kunde !== sessionData.kunde){
                    writeLog('Firmenadmin ' + sessionData.benutzer_id + ' ' + vorname + ' ' + nachname + ' versucht auf fremdes Ticket zuzugreifen: ' + ticketId);
                    return res.status(403).send('Zugriff verweigert: Kein Zugriff auf dieses Ticket');
                }
                await redisClient.expire(sessionKey, SESSION_TTL);
                return next();
            }
            if(sessionData.rolle === 'Benutzer'){
                const ticketId = req.params.id || req.query.id;
                const [rows] = await pool.query("SELECT * FROM tickets WHERE ticket_id = ?", [ticketId]);
                if(rows.length === 0){
                    return res.status(404).send('Ticket nicht gefunden');
                }
                const ticket = rows[0];
                if(ticket.ersteller === sessionData.benutzer_id || ticket.bearbeiter === sessionData.benutzer_id || ticket.cc === sessionData.benutzer_id || ticket.cc2 === sessionData.benutzer_id || ticket.cc3 === sessionData.benutzer_id){
                    await redisClient.expire(sessionKey, SESSION_TTL);
                    return next();
                }
                writeLog('Benutzer ' + sessionData.benutzer_id + ' ' + vorname + ' ' + nachname + ' versucht auf fremdes Ticket zuzugreifen: ' + ticketId);
                return res.status(403).send('Zugriff verweigert: Kein Zugriff auf dieses Ticket');
            }
            return res.status(403).send('Zugriff verweigert: Ungültige Rolle');
        }
    }catch(error){
        writeLog('requireAuth: Redis Fehler: ' + error);
    }
}


export { requireAuth, benutzerKontrolle, requireConnector, requireKunde, requireSystemAdmin, requireFirmenadmin, ticketAuthorization };