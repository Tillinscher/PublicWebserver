import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const logFilePath = path.join(__dirname, "../../webserver.log");

/**
 * Schreibt eine Log-Nachricht mit Zeitstempel in die Logdatei.
 * Erstellt die Datei, falls sie nicht existiert.
 * 
 * @param {string} message - Nachricht, die geloggt werden soll
 */
function writeLog(message) {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] ${message}\n`;

  fs.appendFile(logFilePath, logEntry, (err) => {
    if (err) {
      console.error("Fehler beim Schreiben in die Logdatei:", err);
    }
  });
}

export default writeLog;