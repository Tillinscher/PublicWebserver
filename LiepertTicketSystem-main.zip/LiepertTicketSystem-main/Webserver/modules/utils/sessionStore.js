const fallbackSessions = new Map();
const SESSION_TTL = 30 * 24 * 60 * 60; //30 Tage

export { fallbackSessions, SESSION_TTL };