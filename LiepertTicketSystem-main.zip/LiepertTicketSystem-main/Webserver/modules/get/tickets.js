import pool from "../utils/dbconfig.js";
import writelog from "../utils/writeLog.js";

/**
 * @returns {ticket_id, erp_ticketnr, erstellt, geaendert, ersteller, ersteller_vorname, ersteller_nachname, kunde, kunde_name, beschreibung, anhang, termin, bearbeiter, bearbeiter_vorname, bearbeiter_nachname, cc, cc_vorname, cc_nachname, cc2, cc2_vorname, cc2_nachname, cc3, cc3_vorname, cc3_nachname, status, gelesen, erledigt, angebot, angebot_name, ansprechpartner, ansprechpartner_vorname, ansprechpartner_nachname, projekt, is_in_erp, letzte_bearbeitung, stunden}
 */
function tickets(req, res){
    let { ticket_id, von, bis, kunde, ersteller, bearbeiter, suchbegriff, status } = req.query;
    ticket_id  = ticket_id  ? parseInt(ticket_id, 10)  : null;
    kunde      = kunde      ? parseInt(kunde, 10)      : null;
    ersteller  = ersteller  ? parseInt(ersteller, 10)  : null;
    bearbeiter = bearbeiter ? parseInt(bearbeiter, 10) : null;
    let data;
    if (ticket_id){
        data = [{ticket_id: '1', erstellt: "2025-10-01 08:49:31", erp_ticketnr: "TCKT-001", beschreibung: "Problem mit Drucker und weitere Probleme instrasmst sf jshgf sdgksgfkjsglsd flkj jkhjkhgjkfjgkdjfgldj kjdfkjdf", kunde_name: "KBH", bearbeiter_name: "Konefal", cc_name: "Tillinger", cc2_name: "Liepert", letzte_bearbeitung: "2024-06-01T10:00:00Z", status_text: "Ungelesen", ersteller_name: "Ralf Konefal", stunden: 5}]
    }else{
        data = [
            {ticket_id: '1', erp_ticketnr: "TCKT-001", beschreibung: "Problem mit Drucker und weitere Probleme instrasmst sf jshgf sdgksgfkjsglsd flkj jkhjkhgjkfjgkdjfgldj kjdfkjdf", kunde_name: "Firma A", bearbeiter_name: "Anna Schmidt", letzte_bearbeitung: "2024-06-01T10:00:00Z", status_text: "Ungelesen"},
            {ticket_id: '2', erp_ticketnr: "TCKT-002", beschreibung: "Netzwerkprobleme", kunde_name: "Firma B", bearbeiter_name: "Max Mustermann", letzte_bearbeitung: "2024-06-02T12:30:00Z", status_text: "In Bearbeitung"},
            {ticket_id: '3', erp_ticketnr: "1234", beschreibung: "Software-Update erforderlich", kunde_name: "Firma C", bearbeiter_name: "Lisa Meier", letzte_bearbeitung: "2024-06-03T09:15:00Z", status_text: "Abgeschlossen"}
        ];
    }
    //res.status(200).json(data);

    let val = [];
    let sql = `
        SELECT 
            t.*,
            e.vorname AS ersteller_vorname,
            e.nachname AS ersteller_nachname,
            b.vorname AS bearbeiter_vorname,
            b.nachname AS bearbeiter_nachname,
            c.vorname AS cc_vorname,
            c.nachname AS cc_nachname,
            c2.vorname AS cc2_vorname,
            c2.nachname AS cc2_nachname,
            c3.vorname AS cc3_vorname,
            c3.nachname AS cc3_nachname,
            a.vorname AS ansprechpartner_vorname,
            a.nachname AS ansprechpartner_nachname,
            o.kunde_name AS kunde_name,
            COALESCE(se.letzte_bearbeitung, t.geaendert) AS letzte_bearbeitung
        FROM Tickets t
        LEFT JOIN (
            SELECT 
                ticket_nr,
                MAX(datum) AS letzte_bearbeitung
            FROM Stundeneintraege
            GROUP BY ticket_nr
        ) se ON se.ticket_nr = t.ticket_id
        LEFT JOIN Benutzer e ON t.ersteller = e.benutzer_id
        LEFT JOIN Benutzer b ON t.bearbeiter = b.benutzer_id
        LEFT JOIN Benutzer c ON t.cc = c.benutzer_id
        LEFT JOIN Benutzer c2 ON t.cc2 = c2.benutzer_id
        LEFT JOIN Benutzer c3 ON t.cc3 = c3.benutzer_id
        LEFT JOIN Benutzer a ON t.ansprechpartner = a.benutzer_id
        LEFT JOIN Kunden o ON t.kunde = o.kunden_id
        WHERE 1=1
    `;
    if (ticket_id) {
        sql += " AND t.ticket_id = ?";
        val.push(ticket_id);
    }
    if (von) {
        sql += " AND t.erstellt >= ?";
        val.push(von);
    }
    if (bis) {
        sql += " AND t.erstellt <= ?";
        val.push(bis);
    }
    if (kunde) {
        sql += " AND t.kunde = ?";
        val.push(kunde);
    }
    if (ersteller) {
        sql += " AND t.ersteller = ?";
        val.push(ersteller);
    }
    if (bearbeiter) {
        sql += " AND (t.bearbeiter = ? OR t.cc = ? OR t.cc2 = ? OR t.cc3 = ?)";
        val.push(bearbeiter);
        val.push(bearbeiter);
        val.push(bearbeiter);
        val.push(bearbeiter);
    }
    if (status && !ticket_id) {
        sql += " AND t.status = ?";
        val.push(status);
    }

    if(status !== "geschlossen" && !ticket_id){
        sql += " AND t.status != ?";
        val.push("geschlossen");
    }

    if (suchbegriff){
        sql += " AND (t.beschreibung LIKE ? OR t.erp_ticketnr LIKE ?)";
        val.push(`%${suchbegriff}%`);
        val.push(`%${suchbegriff}%`);
    }

    pool.query(sql, val)
    .then(([rows]) => {
        res.status(200).json(rows);
    })
    .catch((error) => {
        console.error('Fehler bei der Abfrage:', error);
        res.status(500).json({ details: error });
    });
}

/**
 * Gibt die Anzahl der Tickets in verschiedenen Status zurück.
 * @returns { ungelesen: number, gelesen: number, bearbeitung: number, gesamt: number }
 */
function ticketanzahl(req, res){
    let { bearbeiter, ersteller } = req.query;
    ersteller  = ersteller  ? parseInt(ersteller, 10)  : null;
    bearbeiter = bearbeiter ? parseInt(bearbeiter, 10) : null;
    let sql = `
        SELECT
            COUNT(CASE WHEN status = 'ungelesen' THEN 1 END) AS ungelesen,
            COUNT(CASE WHEN status = 'gelesen' THEN 1 END) AS gelesen,
            COUNT(CASE WHEN status = 'bearbeitung' THEN 1 END) AS bearbeitung,
            COUNT(*) AS gesamt
        FROM tickets
    `;
    if(bearbeiter) sql += "WHERE bearbeiter = ?";
    else if(ersteller) sql += "WHERE ersteller = ?";
    else return res.status(404).json({details: "Bearbeiter oder Ersteller muss angegeben sein"});
    //const data = { ungelesen: 5, gelesen: 10, bearbeitung: 3, gesamt: 18 };
    //res.status(200).json(data);
    pool.query(sql, [bearbeiter ? bearbeiter : ersteller])
    .then(([rows]) => {
        res.status(200).json(rows);
    })
    .catch((error) => {
        console.error('Fehler bei der Abfrage:', error);
        res.status(500).json({ details: error });
    });
}

export { tickets, ticketanzahl };