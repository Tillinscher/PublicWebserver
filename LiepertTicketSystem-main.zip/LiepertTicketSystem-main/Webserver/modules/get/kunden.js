import pool from "../utils/dbconfig.js";
import writeLog from "../utils/writeLog.js";

async function kunden(req, res){
    /*
    const data = [
        {kunde_id: 1, kunde_name: "it.liepert.gmbh", projekt_id: 108, projekt_name: "2509", kundenadministratoren: [{admin_name: "Klaus Liepert", adminId: 2}, {admin_name: "Ralf Konefal", adminId: 3}]},
        {kunde_id: 2, kunde_name: "KBH", projekt_id: 109, projekt_name: "2509", kundenadministratoren: [{admin_name: "Markus Huber", adminId: 4}]},
        {kunde_id: 3, kunde_name: "Rauh Schuhaus", projekt_id: 110, projekt_name: "2509", kundenadministratoren: [{admin_name: "Peter Rauh", adminId: 5}]},
    ];
    res.status(200).json(data);*/

    const {kunde_id, suche} = req.query;
    let sql = "SELECT * FROM kunden";
    let params = [];
    if (kunde_id){
        sql += " WHERE kunden_id=?"
        params.push(kunde_id);
    } else if(suche){
        sql += " WHERE kunde_name LIKE ?"
        params.push(`%${suche}%`);
    }



    try {
        const [kunden] = await pool.query(sql, params);

        if (kunden.length === 0) {
            return res.json([]);
        }

        const kundenIds = kunden.map(k => k.kunden_id);

        const [admins] = await pool.query(
            `
            SELECT 
                b.*
            FROM benutzer b
            WHERE b.rolle = 'Firmenadministrator'
            AND b.kunde IN (?)
            `,
            [kundenIds]
        );

        const adminMap = {};
        for (const admin of admins) {
            if (!adminMap[admin.kunde]) {
                adminMap[admin.kunde] = [];
            }
            adminMap[admin.kunde].push(admin);
        }

        const result = kunden.map(kunde => ({
            ...kunde,
            kundenadministratoren: adminMap[kunde.kunden_id] || []
        }));
        res.status(200).json(result);

    } catch (err) {
        writeLog("GET: Fehler bei Kundenauswahl" + err);
        res.status(500).json({ error: "Interner Server Fehler" });
    }
}

export default kunden;