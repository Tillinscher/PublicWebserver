import pool from '../utils/dbconfig.js';
import writeLog from '../utils/writeLog.js';

async function fahrzeuge(req, res){
    const sql = `SELECT * FROM fahrzeuge`;
    try{
        const [result] = await pool.query(sql);
        return res.status(200).json(result);
    }catch(error){
        writeLog('Fehler beim Laden der Fahrzeuge: ' + error);
        return res.status(500).json({details: 'Interner Serverfehler beim Laden der Fahrzeuge'});
    }
}

export default fahrzeuge;