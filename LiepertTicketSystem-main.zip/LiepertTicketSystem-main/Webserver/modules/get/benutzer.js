import pool from "../utils/dbconfig.js";

function benutzer(req, res){
    const { benutzer_id, ersteller, kunde, email, rolle, suche } = req.query;
    const data = [
        { benutzer_id: 1, erstellt: "2024-06-01T10:00:00Z", geaendert: "2024-06-01T10:00:00Z", ersteller: 1, ersteller_name: "Luca Tillinger", vorname: "Klaus", nachname: "Liepert", email: "kl@liepert.de", kuerzel: "kl", rolle: "Firmenadministrator", rolle_text: "Firmenadministrator", letzte_aktion: "2024-06-10T14:30:00Z", kunde: 4, kunde_name: "Musterfirma GmbH", synchronisiert: 1 },
        { benutzer_id: 2, erstellt: "2024-06-01T10:00:00Z", geaendert: "2024-06-01T10:00:00Z", ersteller: 1, ersteller_name: "Luca Tillinger", vorname: "Ralf", nachname: "Konefal", email: "rk@liepert.de", kuerzel: "rk", rolle: "Techniker", rolle_text: "Techniker", letzte_aktion: "2024-06-10T14:30:00Z", kunde: 4, kunde_name: "Musterfirma GmbH", synchronisiert: 1 },
        { benutzer_id: 3, erstellt: "2024-06-01T10:00:00Z", geaendert: "2024-06-01T10:00:00Z", ersteller: 1, ersteller_name: "Luca Tillinger", vorname: "Florian", nachname: "Steinert", email: "fs@liepert.de", kuerzel: "fs", rolle: "Techiker", rolle_text: "Techniker", letzte_aktion: "2024-06-10T14:30:00Z", kunde: 4, kunde_name: "Musterfirma GmbH", synchronisiert: 2 },
    ];

    let params = [];
    if(benutzer_id) params.push(benutzer_id);
    if(ersteller) params.push(ersteller);
    if(kunde) params.push(kunde);
    if(email) params.push(email);
    if(rolle) params.push(rolle);
    if(suche) {
        const suchmuster = `%${suche}%`;
        params.push(suchmuster, suchmuster, suchmuster, suchmuster);
    }

    let sql = `SELECT * FROM Benutzer WHERE aktiv=1 AND benutzer_id != 100`;
    if(benutzer_id) sql += ` AND benutzer_id = ?`;
    if(ersteller) sql += ` AND ersteller = ?`;
    if(kunde) sql += ` AND kunde = ?`;
    if(email) sql += ` AND email = ?`;
    if(rolle) sql += ` AND rolle = ?`;
    if(suche) sql += ` AND (vorname LIKE ? OR nachname LIKE ? OR email LIKE ? OR kuerzel LIKE ?)`;

    pool.query(sql, params)
    .then(([rows]) => {
        res.status(200).json(rows);
    })
    .catch((error) => {
        console.error('Fehler bei der Abfrage:', error);
        res.status(500).json({ details: error });
    });
    //res.status(200).json(data);
}

export default benutzer;