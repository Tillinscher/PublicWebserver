import writeLog from '../utils/writeLog.js';
import pool from '../utils/dbconfig.js';

/**
 * 
 * @param {*} req 
 * @param {*} res
 * Funktion zum Abrufen von Projekten basierend auf Kunden-ID und optionalen Datumsparametern.
 * Query-Parameter:
 * - kunde: ID des Kunden (erforderlich)
 * - von: Startdatum (optional, wenn 'datum' nicht angegeben ist)
 * - bis: Enddatum (optional, wenn 'datum' nicht angegeben ist)
 * - datum: spezifisches Datum (optional, ersetzt 'von' und 'bis' wenn angegeben)
 * @returns 
 */
async function getProjekte(req, res) {
    const { kunde, von, bis, datum, projektId } = req.query;
    if(projektId) {
        const query = `
            SELECT 
                p.*,
                k.kunde_name as kunde_name
            FROM projekte p
            LEFT JOIN kunden k ON p.kunde = k.kunden_id
            WHERE p.lfdnrPRJ = ?`;
        await pool.query(query, [projektId])
            .then(([rows]) => {
                return res.status(200).json(rows);
            })
            .catch((error) => {
                writeLog(`GET /api/projekte - Fehler beim Abrufen des Projekts: ${error.message}`);
                return res.status(500).json({ error: 'Interner Serverfehler' });
            });
        return;
    }
    if(!kunde) {
        writeLog('GET /api/projekte - Fehlende Query Parameter');        
        return res.status(400).json({ error: 'Query Parameter nicht passend' });
    }
    let parameter = [];
    const query = `
        SELECT 
            p.*,
            k.kunde_name as kunde_name
        FROM projekte p
        LEFT JOIN kunden k ON p.kunde = k.kunden_id
        WHERE kunde = ? 
        AND BEGIN <= ? 
        AND END >= ?`;
    if(datum) parameter = [kunde, datum, datum];
    else parameter = [kunde, bis, von];
    await pool.query(query, parameter)
        .then(([rows]) => {
            return res.status(200).json(rows);
        })
        .catch((error) => {
            writeLog(`GET /api/projekte - Fehler beim Abrufen der Projekte: ${error.message}`);
            return res.status(500).json({ error: 'Interner Serverfehler' });
        });
}

export default getProjekte;