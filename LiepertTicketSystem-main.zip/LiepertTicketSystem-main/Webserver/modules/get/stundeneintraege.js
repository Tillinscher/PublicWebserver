import pool from "../utils/dbconfig.js"
import writelog from '../utils/writeLog.js'
import { createClient } from 'redis';
const redisClient = createClient({
    url: 'redis://localhost:6379'
});

(async () =>{
    try{
        await redisClient.connect();
    } catch(err){
        writeLog('requireAuth: Redis Verbindungsfehler: ' + err);
        await redisClient.quit().catch(() => {});
    }
})();

async function getStundeneintraege(req, res) {
    try {
        const ticketId = req.query.ticketid;

        if (!ticketId) {
            writelog("getStundeneintraege: keine ticketId übergeben");
            return res.status(400).send("Bad Request: Ungültige Parameter übergeben");
        }

        const [kundeResults] = await pool.query(
            "SELECT kunde FROM tickets WHERE ticket_id = ? LIMIT 1",
            [ticketId]
        );

        if (kundeResults.length === 0) {
            writelog("getStundeneintraege: keine Tickets für ticketId " + ticketId);
            return res.status(404).send("Not Found");
        }

        let query = `
            SELECT 
                s.*, 
                b.vorname AS Mitarbeiter_vorname, 
                b.nachname AS Mitarbeiter_nachname,
                t.kunde AS kunde
            FROM Stundeneintraege s
            LEFT JOIN benutzer b ON s.mitarbeiter = b.benutzer_id
            LEFT JOIN tickets t ON s.ticket_nr = t.ticket_id
            WHERE s.ticket_nr = ?
        `;

        const token = req.cookies.session_token;
        if (!token) return res.redirect('/login');
        const sessionKey = `sess:${token}`;
        let sessionData;

        try{
            const redisData = await redisClient.get(sessionKey);
            if(redisData){
                sessionData = JSON.parse(redisData);
                if(sessionData.kunde !== 1){
                    query += `AND kundensichtbarkeit = 1`
                }
            }
        }catch(error){
            writelog('stundeneintraege: Redis Fehler: ' + error);
        }

        query += `
            ORDER BY s.datum DESC, s.Zeitvon DESC
            LIMIT 1000
        `

        const [results] = await pool.query(query, [ticketId]);
        return res.status(200).json(results);

    } catch (error) {
        writelog("getStundeneintraege: Fehler: " + error);
        return res.status(500).send("Internal Server Error");
    }
}

export default getStundeneintraege;