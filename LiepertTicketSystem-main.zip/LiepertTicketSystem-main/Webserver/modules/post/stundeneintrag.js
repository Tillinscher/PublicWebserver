import pool from '../utils/dbconfig.js'
import writeLog from '../utils/writeLog.js';


/**
    @param ticket_id - ID of the ticket to associate with the stundeneintrag
    @returns JSON response indicating success or failure of the operation
*/
async function stundeneintrag(req, res) {
    const { ticket_id, mitarbeiter, datum, bis } = req.query;
    if (!ticket_id) {
        writeLog('Missing ticket_id in request body');
        return res.status(400).json({ details: 'Fehlende Argumente' });
    }
    const query = `INSERT INTO stundeneintraege (ticket_nr, mitarbeiter, datum, Zeitbis, Zeit, Zeit_OB) VALUES (?, ?, ?, ?, ?, ?)`;
    try {
        const [result] = await pool.query(query, [ticket_id, mitarbeiter, datum, bis, 0.00, 0.00])
        res.status(201).json({ message: 'Stundeneintrag created successfully', id: result.insertId});
    } catch (error) {
        writeLog('Unexpected error inserting stundeneintrag: ' + error);
        return res.status(500).json({ details: 'Unexpected error: ' + error });
    }
}

export default stundeneintrag;