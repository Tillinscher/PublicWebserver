import pool from '../utils/dbconfig.js';
import writeLog from '../utils/writeLog.js';
import { hashPassword } from '../utils/passwortHash.js';

async function benutzer(req, res){
    let { vorname, nachname, e_mail, rolle, passwort, kunde, ersteller, kuerzel, aktiv } = req.query;
    const sql = "INSERT INTO benutzer (vorname, nachname, email, rolle, passwort, kunde, ersteller, kuerzel, aktiv) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    

    kunde = parseInt(kunde, 10);
    ersteller = parseInt(ersteller, 10);
    aktiv = parseInt(aktiv, 10);
    kuerzel = kuerzel.toLowerCase();
    const passwortHash = await hashPassword(passwort);

    const params = [vorname, nachname, e_mail, rolle, passwortHash, kunde, ersteller, kuerzel, aktiv];
    pool.query(sql, params, (err, results) => {
        if(err){
            writeLog("Fehler beim Erstellen des Benutzers: " + err, "error");
            res.status(500).json({ 
                details: "Fehler beim Erstellen des Benutzers" + err 
            });
            return;
        }
        res.status(200).json({ 
            benutzerId: results.insertId, 
            details: "Erstellen von Benutzer " + vorname + " " + nachname + " erfolgreich." 
        });
    })
    .catch(err => {
        writeLog("Fehler beim Erstellen des Benutzers: " + err, "error");
        res.status(500).json({ 
            details: "Fehler beim Erstellen des Benutzers" + err 
        });
    });
}

export default benutzer;