import pool from '../utils/dbconfig.js';
import writeLog from '../utils/writeLog.js';
import sendEmail from '../utils/email.js';
import { serverAdresse } from '../utils/serverAdresse.js';

/**
 * 
 * @param {*} req 
 * @param {*} res 
 * @param {int} ersteller
 * @param {string} beschreibung
 * @param {int} kunde
 * @param {int} bearbeiter
 * @param {int} cc, cc2, cc3
 * @param {string} status
 * @param {int} ansprechpartner
 * 
 * Über die Funktion wird ein Ticket erstellt und eine Automatische Email an den Kundenbetreuer versendet
 * 
 * @returns eine Antwort an den Server
 */
async function createTicket(req, res){
    let { ersteller, beschreibung, kunde, bearbeiter, cc, cc2, cc3, status, ansprechpartner } = req.query;
    const toIntOrNull = (v) => {
        if (v === undefined || v === null || v === "") return null;
        const n = Number(v);
        return Number.isInteger(n) ? n : null;
    };

    ersteller = toIntOrNull(ersteller);
    kunde = toIntOrNull(kunde);
    bearbeiter = toIntOrNull(bearbeiter);
    bearbeiter = bearbeiter === null ? 101 : bearbeiter;
    cc = toIntOrNull(cc);
    cc2 = toIntOrNull(cc2);
    cc3 = toIntOrNull(cc3);
    ansprechpartner = toIntOrNull(ansprechpartner);

    beschreibung = beschreibung ?? null;
    status = status ?? null;

    const sql = "INSERT INTO tickets (ersteller, kunde, beschreibung, bearbeiter, cc, cc2, cc3, status, ansprechpartner) VALUES (?,?,?,?,?,?,?,?,?)"
    const params = [ersteller, kunde, beschreibung, bearbeiter, cc, cc2, cc3, status, ansprechpartner];
    try{
        const result = await pool.query(sql, params)

        res.status(200).json({
            ticket_id: result[0].insertId,
            details: "Erstellen des Tickets erfolgreich."
        });
        sendeEmailBenachrichtigung(ersteller, beschreibung, kunde, result[0].insertId);
    } catch(err){
        writeLog("Fehler beim Erstellen des Tickets: " + err);
        res.status(500).json({
            details: "Fehler beim Erstellen des Ticket: " + err
        });
    }
}

/**
 * 
 * @param {int} ersteller 
 * @param {string} beschreibung 
 * @param {int} kunde 
 * @param {int} ticketId
 * 
 * Funktion sendet eine email an den Kundenbetreuer
 */
async function sendeEmailBenachrichtigung(ersteller, beschreibung, kunde, ticketId) {
    try {
        const sqlKunde = `
            SELECT k.*, b.email AS empfaenger
            FROM kunden k
            LEFT JOIN benutzer b ON k.kundenbetreuer = b.benutzer_id
            WHERE kunden_id = ?
        `;

        const [kundenResult] = await pool.query(sqlKunde, [kunde]);
        const kunden = kundenResult[0];

        const sqlErsteller = `
            SELECT vorname, nachname
            FROM benutzer
            WHERE benutzer_id = ?
        `;

        const [erstellerResult] = await pool.query(sqlErsteller, [ersteller]);
        const erstellername = erstellerResult[0].vorname + " " + erstellerResult[0].nachname;

        const betreff = `Neues Ticket für Kunde ${kunden.kunde_name}`;
        
        const text = `  
            ${erstellername} erstellte folgendes Ticket:
            ${beschreibung}

            Das Ticket liegt aktuell im Ticketpool.

            Hier geht es zum Ticket:
            ${serverAdresse}/ticket?ticketId=${ticketId}
        `;
        sendEmail(kunden.empfaenger, betreff, text);
        console.log("Email gesendet");
        //console.log(kunden.empfaenger, betreff, html);
    } catch (err) {
        writeLog("Fehler bei E-Mail Benachrichtigung: " + err);
        console.log("Fehler bei E-Mail Benachrichtigun: " + err);
    }
}

export default createTicket;
export { sendeEmailBenachrichtigung };