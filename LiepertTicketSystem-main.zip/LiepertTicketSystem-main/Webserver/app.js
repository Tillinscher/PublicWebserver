import express from 'express';
import path from 'path';
import bodyParser from 'body-parser';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import {requireAuth, requireConnector} from './modules/utils/requireAuth.js';

const app = express();
const PORT = 3030;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


import login from './routes/login.js';
import me from './routes/me.js';
import api from './routes/api.js';
import ticket from './routes/ticket.js';
import logout from './routes/logout.js';
import redisCheck from './modules/utils/redisCheck.js';
import connection from './routes/connection.js';

app.use(bodyParser.json());
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'static')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '/static'));

app.use('/login', login);
app.get('/', requireAuth, (req, res) => {
    res.render('home');
});
app.use('/me', requireAuth, me);
app.use('/api', requireAuth, api);
app.use('/logout', requireAuth, logout);
app.use('/ticket', requireAuth, ticket);
app.use('/connection', requireConnector, connection);

//Routen zum senden von HTML Seiten
app.get('/tickets', requireAuth, (req, res) => {
    res.render('tickets');
});
app.get('/firmenverwaltung', requireAuth, async (req, res) => {
    const kunde = req.user.kunde_name;
    res.render('firmenverwaltung', { kunde });
});
app.get('/systemverwaltung', requireAuth, (req, res) => {
    res.render('systemverwaltung');
});

app.listen(PORT, () => {
    redisCheck();
    console.log(`Server läuft auf http://localhost:${PORT}`);
});